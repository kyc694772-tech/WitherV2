import configparser
import random
import string
import time

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_cfg = configparser.ConfigParser()
_cfg.read("config.ini")

def _get(section, key, fallback=None):
    try:
        return _cfg.get(section, key).strip()
    except Exception:
        return fallback

AUTO_SET_NAME  = _get("AutoOps", "auto_set_name",  "false").lower() == "true"
NAME_FORMAT    = _get("AutoOps", "custom_name_format", "MeowMal_{random_letter}_{random_number}")
MAX_RETRIES    = int(_get("General", "max_retries", "3"))
TIMEOUT        = int(_get("General", "timeout", "10"))

_NAMECHANGE_URL = "https://api.minecraftservices.com/minecraft/profile/namechange"
_RENAME_URL     = "https://api.minecraftservices.com/minecraft/profile/name/"

def _resolve_name_format(name_format):
    name = name_format
    while "{random_letter}" in name:
        name = name.replace("{random_letter}", random.choice(string.ascii_lowercase), 1)
    while "{random_number}" in name:
        name = name.replace("{random_number}", random.choice(string.digits), 1)
    while "{random_string}" in name:
        name = name.replace("{random_string}", "".join(random.choices(string.ascii_lowercase + string.digits, k=3)), 1)
    if name == name_format and len(name) < 13:
        name = f"{name}_{''.join(random.choices(string.ascii_lowercase + string.digits, k=3))}"
    return name

def is_rename_available(session, mc_token):
    tries = 0
    while tries < MAX_RETRIES:
        try:
            r = session.get(
                _NAMECHANGE_URL,
                headers={"Authorization": f"Bearer {mc_token}"},
                timeout=TIMEOUT,
            )
            if r.status_code == 200:
                return r.json().get("nameChangeAllowed", False)
            if r.status_code == 429:
                time.sleep(0.5)
        except Exception:
            pass
        tries += 1
    return False

def rename_account(session, mc_token, current_name=None):
    if not AUTO_SET_NAME:
        return {"success": False, "reason": "disabled", "new_name": None}

    if not is_rename_available(session, mc_token):
        return {"success": False, "reason": "cooldown", "new_name": None}

    new_name = _resolve_name_format(NAME_FORMAT)
    tries = 0
    while tries < MAX_RETRIES:
        try:
            r = session.put(
                _RENAME_URL + new_name,
                headers={"Authorization": f"Bearer {mc_token}"},
                timeout=TIMEOUT,
            )
            if r.status_code == 200:
                display = f"{current_name} -> {new_name}" if current_name else new_name
                return {"success": True, "reason": None, "new_name": new_name, "display": display}
            if r.status_code == 429:
                time.sleep(0.5)
            elif r.status_code == 400:
                return {"success": False, "reason": "invalid_name", "new_name": new_name}
        except Exception:
            pass
        tries += 1

    return {"success": False, "reason": "failed", "new_name": new_name}