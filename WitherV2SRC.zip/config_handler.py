"""
config_handler.py
Handles loading and parsing of config.ini settings
"""

import configparser
import os
import threading

# Global lock for file operations
file_lock = threading.Lock()


class ConfigHandler:
    def __init__(self, config_file='config.ini'):
        self.config_file = config_file
        self.config = configparser.ConfigParser()
        self.settings = {}
        self._load_config()
    
    def _load_config(self):
        """Load configuration from config.ini"""
        if not os.path.exists(self.config_file):
            self._create_default_config()
            return
        
        try:
            self.config.read(self.config_file, encoding='utf-8')
            self._parse_all_sections()
        except Exception as e:
            print(f"Error loading config: {e}")
            self._create_default_config()
    
    def _create_default_config(self):
        """Create default configuration"""
        defaults = {
            'General': {
                'threads': '100',
                'timeout': '3',
                'max_retries': '3',
                'use_proxies': 'false'
            },
            'Performance': {
                'optimize_network': 'true',
                'connection_pool_size': '150',
                'dns_cache_enabled': 'true',
                'keep_alive_enabled': 'true'
            },
            'Proxy': {
                'auto_proxy': 'false',
                'proxy_api': '',
                'request_num': '3',
                'proxy_time': '5',
                'proxy_rotation': 'true',
                'verify_ssl': 'false'
            },
            'Features': {
                'check_xbox_game_pass': 'true',
                'check_xbox_game_pass_ultimate': 'true',
                'check_minecraft_ownership': 'true',
                'check_minecraft_capes': 'true',
                'check_optifine_cape': 'true',
                'check_name_change': 'true',
                'check_last_name_change': 'true',
                'check_hypixel_rank': 'true',
                'check_hypixel_level': 'true',
                'check_hypixel_first_login': 'true',
                'check_hypixel_last_login': 'true',
                'check_hypixel_ban_status': 'true',
                'check_bedwars_stars': 'true',
                'check_skyblock_coins': 'true',
                'check_skyblock_networth': 'true',
                'check_payment': 'false',
                'check_credit_cards': 'false',
                'check_paypal': 'false',
                'check_billing_address': 'false',
                'check_subscriptions': 'false',
                'check_purchase_history': 'false',
                'check_microsoft_balance': 'false',
                'check_reward_points': 'false',
                'check_orders': 'false',
                'check_payment_methods': 'false',
                'check_email_access': 'true',
                'check_two_factor': 'false',
                'extract_codes': 'false'
            },
            'Inbox': {
                'scan_inbox': 'false',
                'inbox_keywords': 'steam, netflix, Crunchyroll',
                'max_inbox_messages': '50',
                'save_full_emails': 'false'
            },
            'BanChecking': {
                'enable_ban_checking': 'true',
                'hypixelban': 'true',
                'use_ban_proxies': 'false'
            },
            'Data_Collection': {
                'hypixel_name': 'true',
                'hypixel_level': 'true',
                'first_hypixel_login': 'true',
                'last_hypixel_login': 'true',
                'optifine_cape': 'true',
                'minecraft_capes': 'true',
                'email_access': 'true',
                'hypixel_skyblock_coins': 'true',
                'hypixel_bedwars_stars': 'true',
                'hypixel_ban': 'true',
                'name_change_availability': 'true',
                'last_name_change': 'true',
                'payment': 'true'
            },
            'File_Output': {
                'save_hits': 'true',
                'save_bad': 'false',
                'save_valid_mail': 'true',
                'save_2fa': 'false',
                'save_banned': 'true',
                'save_unbanned': 'true',
                'save_mfa': 'true',
                'save_sfa': 'true',
                'save_normal_minecraft': 'true',
                'save_xbox_game_pass': 'true',
                'save_xbox_game_pass_ultimate': 'true',
                'save_other': 'false',
                'create_capture_file': 'true',
                'create_separate_files': 'true'
            },
            'Discord': {
                'enable_notifications': 'false',
                'discord_webhook_url': '',
                'webhook_username': 'MeowMal Checker',
                'webhook_avatar_url': '',
                'notify_on_hit': 'true',
                'notify_on_game_pass': 'true',
                'notify_on_payment': 'false',
                'notify_on_2fa': 'false',
                'notify_on_mfa': 'true',
                'notify_on_hypixel_rank': 'true',
                'embed_color_hit': '#57F287',
                'embed_color_xgp': '#3498DB',
                'embed_thumbnail': 'true',
                'embed_footer': 'true',
                'embed_thumbnail_url': '',
                'embed_image_enabled': 'true',
                'embed_image_template': 'https://hypixel.paniek.de/signature/{uuid}/general-tooltip'
            },
            'Security': {
                'mark_mfa': 'true',
                'mark_sfa': 'true'
            },
            'RateLimit': {
                'delay_between_checks': '0',
                'random_delay': 'true',
                'min_delay': '0',
                'max_delay': '2',
                'respect_429': 'true',
                'pause_on_429': '20',
                'random_user_agent': 'true',
                'warn_on_slow_check': 'false',
                'slow_check_warn_seconds': '75'
            },
            'Filters': {
                'min_hypixel_level': '0',
                'min_bedwars_stars': '0',
                'min_skyblock_coins': '0',
                'min_account_balance': '0',
                'require_payment_method': 'false',
                'require_full_access': 'false',
                'require_unbanned': 'false'
            },
            'AutoOps': {
                'auto_set_name': 'false',
                'custom_name_format': 'MeowMal_{random_letter}_{random_number}',
                'auto_set_skin': 'false',
                'http://text 'skin_url':ures.minecraft.net/texture/example',
                'skin_variant': 'classic'
            },
            'DonutSMP': {
                'donut_stats': 'false',
                'donut_api_key': ''
            },
            'UI': {
                'show_live_logs': 'true',
                'print_to_console': 'true',
                'colored_output': 'true',
                'verbose_mode': 'false',
                'theme': 'blue'
            }
        }
        
        for section, options in defaults.items():
            if not self.config.has_section(section):
                self.config.add_section(section)
            for key, value in options.items():
                self.config.set(section, key, value)
        
        self._parse_all_sections()
    
    def _parse_all_sections(self):
        """Parse all config sections into a flat dictionary"""
        for section in self.config.sections():
            for key, value in self.config.items(section):
                self.settings[key] = self._parse_value(value)
    
    def _parse_value(self, value):
        """Parse config value to appropriate type"""
        if not isinstance(value, str):
            return value
        value = value.strip().lower()
        if value in ('true', 'yes', '1', 'on'):
            return True
        if value in ('false', 'no', '0', 'off'):
            return False
        try:
            if '.' not in value:
                return int(value)
            return float(value)
        except ValueError:
            pass
        return value
    
    def get(self, key, default=None):
        """Get a config value"""
        return self.settings.get(key, default)
    
    def get_threads(self):
        """Get thread count"""
        return self.get('threads', 100)
    
    def get_timeout(self):
        """Get timeout value"""
        return self.get('timeout', 3)
    
    def get_max_retries(self):
        """Get max retries"""
        return self.get('max_retries', 3)
    
    def get_use_proxies(self):
        """Get use_proxies setting"""
        return self.get('use_proxies', False)
    
    # Feature checks
    def check_xbox_game_pass(self):
        return self.get('check_xbox_game_pass', True)
    
    def check_xbox_game_pass_ultimate(self):
        return self.get('check_xbox_game_pass_ultimate', True)
    
    def check_minecraft_ownership(self):
        return self.get('check_minecraft_ownership', True)
    
    def check_minecraft_capes(self):
        return self.get('check_minecraft_capes', True)
    
    def check_optifine_cape(self):
        return self.get('check_optifine_cape', True)
    
    def check_name_change(self):
        return self.get('check_name_change', True)
    
    def check_last_name_change(self):
        return self.get('check_last_name_change', True)
    
    def check_hypixel_rank(self):
        return self.get('check_hypixel_rank', True)
    
    def check_hypixel_level(self):
        return self.get('check_hypixel_level', True)
    
    def check_hypixel_first_login(self):
        return self.get('check_hypixel_first_login', True)
    
    def check_hypixel_last_login(self):
        return self.get('check_hypixel_last_login', True)
    
    def check_hypixel_ban_status(self):
        return self.get('check_hypixel_ban_status', True)
    
    def check_bedwars_stars(self):
        return self.get('check_bedwars_stars', True)
    
    def check_skyblock_coins(self):
        return self.get('check_skyblock_coins', True)
    
    def check_skyblock_networth(self):
        return self.get('check_skyblock_networth', True)
    
    def check_payment(self):
        return self.get('check_payment', False)
    
    def check_credit_cards(self):
        return self.get('check_credit_cards', False)
    
    def check_paypal(self):
        return self.get('check_paypal', False)
    
    def check_billing_address(self):
        return self.get('check_billing_address', False)
    
    def check_subscriptions(self):
        return self.get('check_subscriptions', False)
    
    def check_purchase_history(self):
        return self.get('check_purchase_history', False)
    
    def check_microsoft_balance(self):
        return self.get('check_microsoft_balance', False)
    
    def check_reward_points(self):
        return self.get('check_reward_points', False)
    
    def check_orders(self):
        return self.get('check_orders', False)
    
    def check_payment_methods(self):
        return self.get('check_payment_methods', False)
    
    def check_email_access(self):
        return self.get('check_email_access', True)
    
    def check_two_factor(self):
        return self.get('check_two_factor', False)
    
    def scan_inbox(self):
        return self.get('scan_inbox', False)
    
    def get_inbox_keywords(self):
        return self.get('inbox_keywords', 'steam, netflix, Crunchyroll')
    
    def enable_ban_checking(self):
        return self.get('enable_ban_checking', True)
    
    def get_hypixelban(self):
        return self.get('hypixelban', True)
    
    def use_ban_proxies(self):
        return self.get('use_ban_proxies', False)
    
    # Output settings
    def save_hits(self):
        return self.get('save_hits', True)
    
    def save_bad(self):
        return self.get('save_bad', False)
    
    def save_valid_mail(self):
        return self.get('save_valid_mail', True)
    
    def save_2fa(self):
        return self.get('save_2fa', False)
    
    def save_banned(self):
        return self.get('save_banned', True)
    
    def save_unbanned(self):
        return self.get('save_unbanned', True)
    
    def save_mfa(self):
        return self.get('save_mfa', True)
    
    def save_sfa(self):
        return self.get('save_sfa', True)
    
    def save_normal_minecraft(self):
        return self.get('save_normal_minecraft', True)
    
    def save_xbox_game_pass(self):
        return self.get('save_xbox_game_pass', True)
    
    def save_xbox_game_pass_ultimate(self):
        return self.get('save_xbox_game_pass_ultimate', True)
    
    # Discord settings
    def enable_notifications(self):
        return self.get('enable_notifications', False)
    
    def get_discord_webhook_url(self):
        return self.get('discord_webhook_url', '')
    
    def get_webhook_username(self):
        return self.get('webhook_username', 'MeowMal Checker')
    
    # DonutSMP settings
    def donut_stats_enabled(self):
        return self.get('donut_stats', False)
    
    def get_donut_api_key(self):
        return self.get('donut_api_key', '')
    
    # AutoOps settings
    def auto_set_name(self):
        return self.get('auto_set_name', False)
    
    def get_custom_name_format(self):
        return self.get('custom_name_format', 'MeowMal_{random_letter}_{random_number}')
    
    def auto_set_skin(self):
        return self.get('auto_set_skin', False)
    
    def get_skin_url(self):
        return self.get('skin_url', 'http://textures.minecraft.net/texture/example')
    
    def get_skin_variant(self):
        return self.get('skin_variant', 'classic')
    
    # Filter settings
    def get_min_hypixel_level(self):
        return self.get('min_hypixel_level', 0)
    
    def get_min_bedwars_stars(self):
        return self.get('min_bedwars_stars', 0)
    
    def get_min_skyblock_coins(self):
        return self.get('min_skyblock_coins', 0)
    
    # UI settings
    def show_live_logs(self):
        return self.get('show_live_logs', True)
    
    def print_to_console(self):
        return self.get('print_to_console', True)
    
    def colored_output(self):
        return self.get('colored_output', True)
    
    # Rate limit settings
    def get_delay_between_checks(self):
        return self.get('delay_between_checks', 0)
    
    def get_random_delay(self):
        return self.get('random_delay', True)
    
    def get_min_delay(self):
        return self.get('min_delay', 0)
    
    def get_max_delay(self):
        return self.get('max_delay', 2)
    
    def get_respect_429(self):
        return self.get('respect_429', True)
    
    def get_pause_on_429(self):
        return self.get('pause_on_429', 20)
    
    # Proxy settings
    def get_auto_proxy(self):
        return self.get('auto_proxy', False)
    
    def get_proxy_api(self):
        return self.get('proxy_api', '')
    
    def get_request_num(self):
        return self.get('request_num', 3)
    
    def get_proxy_time(self):
        return self.get('proxy_time', 5)
    
    # Performance settings
    def get_optimize_network(self):
        return self.get('optimize_network', True)
    
    def get_connection_pool_size(self):
        return self.get('connection_pool_size', 150)
    
    def get_dns_cache_enabled(self):
        return self.get('dns_cache_enabled', True)
    
    def get_keep_alive_enabled(self):
        return self.get('keep_alive_enabled', True)


# Global config instance
config = None


def init_config(config_file='config.ini'):
    """Initialize the global config"""
    global config
    config = ConfigHandler(config_file)
    return config


def get_config():
    """Get the global config instance"""
    global config
    if config is None:
        config = ConfigHandler()
    return config
