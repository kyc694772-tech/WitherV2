import re
import time
from urllib.parse import urlparse, parse_qs

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_TOKEN_CACHE = {}
_TOKEN_CACHE_TIMEOUT = 300

_CLIENT_ID   = "000000000004773A"
_SCOPE       = "PIFD.Read+PIFD.Create+PIFD.Update+PIFD.Delete"
_REDIRECT    = "https://account.microsoft.com/auth/complete-silent-delegate-auth"
_BALANCE_URL = "https://paymentinstruments.mp.microsoft.com/v6.0/users/me/paymentInstrumentsEx?status=active,removed&language=en-GB"

def _get_auth_token(session, client_id, scope, redirect_uri, timeout=10):
    cache_key = f"{client_id}:{scope}:{redirect_uri}"
    if cache_key in _TOKEN_CACHE:
        entry = _TOKEN_CACHE[cache_key]
        if time.time() - entry["timestamp"] < _TOKEN_CACHE_TIMEOUT:
            return entry["token"]
    try:
        auth_url = (
            f"https://login.live.com/oauth20_authorize.srf"
            f"?client_id={client_id}&response_type=token"
            f"&scope={scope}&redirect_uri={redirect_uri}&prompt=none"
        )
        r = session.get(auth_url, timeout=timeout)
        token = parse_qs(urlparse(r.url).fragment).get("access_token", [None])[0]
        if token:
            _TOKEN_CACHE[cache_key] = {"token": token, "timestamp": time.time()}
        return token
    except (requests.RequestException, TimeoutError, ConnectionError):
        return None

def check_balance(session, timeout=10):
    try:
        token = _get_auth_token(session, _CLIENT_ID, _SCOPE, _REDIRECT, timeout)
        if not token:
            return None
        headers = {
            "Authorization": f"MSADELEGATE1.0={token}",
            "Accept": "application/json",
        }
        r = session.get(_BALANCE_URL, headers=headers, timeout=15)
        if r.status_code == 200:
            balance_match = re.search(r'"balance":(\d+\.?\d*)', r.text)
            if balance_match:
                balance = balance_match.group(1)
                currency_match = re.search(r'"currency":"([A-Z]{3})"', r.text)
                currency = currency_match.group(1) if currency_match else "USD"
                return f"{balance} {currency}"
        return "0.00 USD"
    except (requests.RequestException, TimeoutError, ConnectionError, ValueError):
        return None