import re
import time

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_HEADERS_MAIN = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Pragma": "no-cache",
    "Accept": "*/*",
}
_HEADERS_HOME = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Referer": "https://www.bing.com/",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
}
_HEADERS_FLYOUT = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Accept-Encoding": "identity",
    "Referer": "https://www.bing.com/",
    "X-Requested-With": "XMLHttpRequest",
}

def check_reward_points(session, timeout=10):
    try:
        r = session.get("https://rewards.bing.com/", headers=_HEADERS_MAIN, timeout=timeout)

        if 'action="https://rewards.bing.com/signin-oidc"' in r.text or 'id="fmHF"' in r.text:
            action_match = re.search('action="([^"]+)"', r.text)
            if action_match:
                action_url = action_match.group(1)
                post_data = {}
                for m in re.finditer('<input type="hidden" name="([^"]+)" id="[^"]+" value="([^"]+)">', r.text):
                    post_data[m.group(1)] = m.group(2)
                r = session.post(action_url, data=post_data, headers=_HEADERS_MAIN, timeout=timeout)

        all_matches = re.findall(r',"availablePoints":(\d+)', r.text)
        if all_matches:
            points = max(all_matches, key=int)
            if points != "0":
                return points

        session.get("https://www.bing.com/", headers=_HEADERS_HOME, timeout=15)

        ts = int(time.time() * 1000)
        r_flyout = session.get(
            f"https://www.bing.com/rewards/panelflyout/getuserinfo?timestamp={ts}",
            headers=_HEADERS_FLYOUT,
            timeout=15,
        )
        if r_flyout.status_code == 200:
            try:
                data = r_flyout.json()
                if data.get("userInfo", {}).get("isRewardsUser"):
                    balance = data.get("userInfo", {}).get("balance")
                    return str(balance)
            except ValueError:
                pass

        return None
    except Exception:
        return None