import json
import re
import time
import warnings
from urllib.parse import urlparse, parse_qs

import requests
import urllib3

warnings.filterwarnings("ignore")
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_TIMEOUT = 15
MAX_RETRIES = 3

# Microsoft OAuth client IDs
PAYMENT_CLIENT_ID = "000000000004773A"
PAYMENT_REDIRECT_URI = "https://account.microsoft.com/auth/complete-silent-delegate-auth"
PAYMENT_SCOPE = "PIFD.Read+PIFD.Create+PIFD.Update+PIFD.Delete"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def new_session() -> requests.Session:
    """Create a new requests session with proper headers."""
    s = requests.Session()
    s.headers.update({
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/120.0.0.0 Safari/537.36"
        ),
        "Accept": "application/json",
    })
    s.verify = False
    return s


def get_payment_token(session: requests.Session) -> str:
    """
    Get Microsoft payment access token via OAuth.
    
    Returns:
        str - Access token on success
        None - Failed to get token
    """
    for _ in range(MAX_RETRIES):
        try:
            auth_url = (
                f"https://login.live.com/oauth20_authorize.srf"
                f"?client_id={PAYMENT_CLIENT_ID}"
                f"&response_type=token"
                f"&scope={PAYMENT_SCOPE}"
                f"&redirect_uri={PAYMENT_REDIRECT_URI}"
                f"&prompt=none"
            )
            
            response = session.get(auth_url, timeout=DEFAULT_TIMEOUT)
            
            # Extract token from URL fragment
            if "#" in response.url:
                token = parse_qs(urlparse(response.url).fragment).get("access_token", [None])[0]
                if token:
                    return token
                    
        except Exception:
            pass
        time.sleep(0.1)
    
    return None


def lr_parse(source: str, start_delim: str, end_delim: str, create_empty: bool = True) -> str:
    """Helper function to parse values from JSON text using delimiters."""
    pattern = re.escape(start_delim) + "(.*?)" + re.escape(end_delim)
    match = re.search(pattern, source)
    if match:
        return match.group(1)
    return "" if create_empty else None


# ---------------------------------------------------------------------------
# Payment Methods Checking
# ---------------------------------------------------------------------------

def check_payment_instruments(session: requests.Session, access_token: str) -> dict:
    """
    Check for linked payment methods (credit cards, PayPal).
    
    Returns dict with:
        - credit_cards: list of credit card info (type, last4, expiry)
        - paypal: list of linked PayPal emails
        - raw_instruments: list of formatted instrument strings
    """
    result = {
        "credit_cards": [],
        "paypal": [],
        "raw_instruments": [],
    }
    
    try:
        headers = {
            "Authorization": f"MSADELEGATE1.0={access_token}",
            "Accept": "application/json",
        }
        
        url = (
            "https://paymentinstruments.mp.microsoft.com/v6.0/users/me/"
            "paymentInstrumentsEx?status=active,removed&language=en-GB"
        )
        
        response = session.get(url, headers=headers, timeout=DEFAULT_TIMEOUT)
        
        if response.status_code != 200:
            return result
            
        try:
            data = response.json()
        except json.JSONDecodeError:
            # Try parsing manually if JSON fails
            pass
        else:
            if isinstance(data, list):
                for item in data:
                    if "paymentMethod" not in item:
                        continue
                        
                    pm = item["paymentMethod"]
                    family = pm.get("paymentMethodFamily")
                    type_ = pm.get("paymentMethodType")
                    
                    if family == "credit_card":
                        last4 = pm.get("lastFourDigits", "N/A")
                        expiry = f"{pm.get('expiryMonth', '')}/{pm.get('expiryYear', '')}"
                        card_type = pm.get("display", {}).get("name", type_)
                        
                        card_info = {
                            "type": card_type,
                            "last4": last4,
                            "expiry": expiry,
                        }
                        result["credit_cards"].append(card_info)
                        result["raw_instruments"].append(
                            f"CC: {card_type} *{last4} ({expiry})"
                        )
                        
                    elif family == "paypal":
                        email = pm.get("email", "N/A")
                        result["paypal"].append(email)
                        result["raw_instruments"].append(f"PayPal: {email}")
                        
    except Exception:
        pass
        
    return result


def check_subscriptions(session: requests.Session, access_token: str) -> list:
    """
    Check active subscriptions.
    
    Returns list of subscription info dicts.
    """
    subscriptions = []
    
    try:
        headers = {
            "Authorization": f"MSADELEGATE1.0={access_token}",
            "Accept": "application/json",
        }
        
        response = session.get(
            "https://account.microsoft.com/services/api/subscriptions",
            headers=headers,
            timeout=DEFAULT_TIMEOUT,
        )
        
        if response.status_code == 200:
            try:
                data = response.json()
                if isinstance(data, list):
                    for item in data:
                        if item.get("status") == "Active":
                            sub_info = {
                                "name": item.get("productName", "Unknown"),
                                "recurrence": item.get("recurrenceState", ""),
                                "status": item.get("status", ""),
                            }
                            subscriptions.append(sub_info)
            except json.JSONDecodeError:
                pass
                
    except Exception:
        pass
        
    return subscriptions


def check_billing_addresses(session: requests.Session, access_token: str) -> list:
    """
    Check billing addresses.
    
    Returns list of address dicts.
    """
    addresses = []
    
    try:
        headers = {
            "Authorization": f"MSADELEGATE1.0={access_token}",
            "Accept": "application/json",
        }
        
        response = session.get(
            "https://account.microsoft.com/billing/api/addresses",
            headers=headers,
            timeout=DEFAULT_TIMEOUT,
        )
        
        if response.status_code == 200:
            try:
                data = response.json()
                if isinstance(data, list):
                    for item in data:
                        address = {
                            "line1": item.get("line1", ""),
                            "line2": item.get("line2", ""),
                            "city": item.get("city", ""),
                            "region": item.get("region", ""),
                            "postal_code": item.get("postalCode", ""),
                            "country": item.get("country", ""),
                        }
                        # Format as single string
                        full_address = ", ".join(
                            str(v) for v in [
                                address["line1"],
                                address["city"],
                                address["postal_code"],
                                address["country"],
                            ] if v
                        )
                        address["formatted"] = full_address
                        addresses.append(address)
            except json.JSONDecodeError:
                pass
                
    except Exception:
        pass
        
    return addresses


def check_account_balance(session: requests.Session, access_token: str) -> dict:
    """
    Check Microsoft account balance.
    
    Returns dict with:
        - balance: string like "10.50 USD"
        - currency: currency code
        - amount: numeric amount
    """
    result = {
        "balance": None,
        "currency": "USD",
        "amount": 0.0,
    }
    
    try:
        headers = {
            "Authorization": f"MSADELEGATE1.0={access_token}",
            "Accept": "application/json",
        }
        
        url = (
            "https://paymentinstruments.mp.microsoft.com/v6.0/users/me/"
            "paymentInstrumentsEx?status=active,removed&language=en-GB"
        )
        
        response = session.get(url, headers=headers, timeout=DEFAULT_TIMEOUT)
        
        if response.status_code == 200:
            balance_match = re.search(r'"balance":(\d+\.?\d*)', response.text)
            if balance_match:
                amount = float(balance_match.group(1))
                currency_match = re.search(r'"currency":"([A-Z]{3})"', response.text)
                currency = currency_match.group(1) if currency_match else "USD"
                
                result["balance"] = f"{amount:.2f} {currency}"
                result["currency"] = currency
                result["amount"] = amount
                
    except Exception:
        pass
        
    return result


# ---------------------------------------------------------------------------
# High-level Combined Checker
# ---------------------------------------------------------------------------

def check_payment_methods(
    session: requests.Session,
    access_token: str,
    include_cards: bool = True,
    include_paypal: bool = True,
    include_subs: bool = True,
    include_addresses: bool = True,
    include_balance: bool = True,
) -> dict:
    """
    Run the full payment methods checker pipeline.
    
    Returns dict with all payment-related information.
    """
    result = {
        "email": None,
        "has_payment_method": False,
        "credit_cards": [],
        "paypal": [],
        "subscriptions": [],
        "billing_addresses": [],
        "balance": None,
        "balance_amount": 0.0,
        "raw_instruments": [],
        "summary": None,
    }
    
    # Check payment instruments
    if include_cards or include_paypal:
        instruments = check_payment_instruments(session, access_token)
        
        if include_cards:
            result["credit_cards"] = instruments.get("credit_cards", [])
            
        if include_paypal:
            result["paypal"] = instruments.get("paypal", [])
            
        result["raw_instruments"] = instruments.get("raw_instruments", [])
        
    # Check subscriptions
    if include_subs:
        result["subscriptions"] = check_subscriptions(session, access_token)
        
    # Check billing addresses
    if include_addresses:
        result["billing_addresses"] = check_billing_addresses(session, access_token)
        
    # Check balance
    if include_balance:
        balance_info = check_account_balance(session, access_token)
        result["balance"] = balance_info.get("balance")
        result["balance_amount"] = balance_info.get("amount", 0.0)
        
    # Determine if account has payment method
    result["has_payment_method"] = (
        len(result["credit_cards"]) > 0 or 
        len(result["paypal"]) > 0 or
        result["balance_amount"] > 0
    )
    
    # Build summary string
    summary_parts = []
    
    if result["credit_cards"]:
        card_count = len(result["credit_cards"])
        summary_parts.append(f"{card_count} CC")
        
    if result["paypal"]:
        pp_count = len(result["paypal"])
        summary_parts.append(f"{pp_count} PayPal")
        
    if result["subscriptions"]:
        sub_count = len(result["subscriptions"])
        summary_parts.append(f"{sub_count} Subs")
        
    if result["balance"]:
        summary_parts.append(f"Bal: {result['balance']}")
        
    if result["billing_addresses"]:
        addr_count = len(result["billing_addresses"])
        summary_parts.append(f"{addr_count} Addr")
        
    result["summary"] = " | ".join(summary_parts) if summary_parts else None
    
    return result


# ---------------------------------------------------------------------------
# Full Payment Check (with token acquisition)
# ---------------------------------------------------------------------------

def check_microsoft_payment(
    email: str,
    password: str,
    session: requests.Session = None,
) -> dict:
    """
    Full payment methods check including authentication.
    
    This function handles the Microsoft OAuth flow to get the payment token,
    then retrieves all payment information.
    
    Returns dict with payment info (same as check_payment_methods).
    """
    if session is None:
        session = new_session()
        
    result = {
        "email": email,
        "success": False,
        "has_payment_method": False,
        "credit_cards": [],
        "paypal": [],
        "subscriptions": [],
        "billing_addresses": [],
        "balance": None,
        "balance_amount": 0.0,
        "raw_instruments": [],
        "summary": None,
    }
    
    # Get payment token
    access_token = get_payment_token(session)
    
    if not access_token:
        # Try alternative method - use the payment function approach
        try:
            # This is the fallback method from the original meow.py
            headers = {
                "Host": "login.live.com",
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "Referer": "https://account.microsoft.com/",
            }
            
            r = session.get(
                "https://login.live.com/oauth20_authorize.srf"
                f"?client_id={PAYMENT_CLIENT_ID}"
                "&response_type=token"
                f"&scope={PAYMENT_SCOPE}"
                "&redirect_uri=https%3A%2F%2Faccount.microsoft.com%2Fauth%2Fcomplete-silent-delegate-auth"
                "&state=%7B%22userId%22%3A%22bf3383c9b44aa8c9%22%2C%22scopeSet%22%3A%22pidl%22%7D"
                "&prompt=none",
                headers=headers,
                timeout=DEFAULT_TIMEOUT,
            )
            
            access_token = parse_qs(urlparse(r.url).fragment).get("access_token", [None])[0]
            
        except Exception:
            pass
            
    if not access_token:
        return result
        
    # Get all payment info
    payment_info = check_payment_methods(session, access_token)
    
    # Merge results
    result.update(payment_info)
    result["success"] = True
    
    return result


# ---------------------------------------------------------------------------
# CLI entry-point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python paymentmethods_checker.py <email> [password]")
        print("       (If password provided, will attempt full auth flow)")
        sys.exit(1)
    
    email = sys.argv[1]
    password = sys.argv[2] if len(sys.argv) > 2 else None
    
    session = new_session()
    
    if password:
        # Full check with authentication
        print(f"[*] Checking payment methods for {email}...")
        result = check_microsoft_payment(email, password, session)
    else:
        # Token must be provided (for advanced use)
        print("Error: Password required for payment methods check")
        sys.exit(1)
    
    print("\n=== Payment Methods Result ===")
    print(f"  Email: {result.get('email')}")
    print(f"  Success: {result.get('success')}")
    print(f"  Has Payment Method: {result.get('has_payment_method')}")
    
    if result.get("credit_cards"):
        print(f"\n  Credit Cards:")
        for card in result["credit_cards"]:
            print(f"    - {card['type']} *{card['last4']} ({card['expiry']})")
            
    if result.get("paypal"):
        print(f"\n  PayPal Accounts:")
        for pp in result["paypal"]:
            print(f"    - {pp}")
            
    if result.get("subscriptions"):
        print(f"\n  Subscriptions:")
        for sub in result["subscriptions"]:
            print(f"    - {sub['name']} ({sub['recurrence']})")
            
    if result.get("billing_addresses"):
        print(f"\n  Billing Addresses:")
        for addr in result["billing_addresses"]:
            print(f"    - {addr.get('formatted', 'N/A')}")
            
    if result.get("balance"):
        print(f"\n  Balance: {result['balance']}")
        
    if result.get("summary"):
        print(f"\n  Summary: {result['summary']}")
