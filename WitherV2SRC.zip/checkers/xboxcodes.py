import random
import string
import time
from typing import Dict, List, Optional, Tuple

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

MAX_RETRIES = 3
BASE_DELAY  = 2

def _get_user_token(session: requests.Session, rps_token: str) -> Optional[str]:
    try:
        response = session.post(
            "https://user.auth.xboxlive.com/user/authenticate",
            json={
                "RelyingParty": "http://auth.xboxlive.com",
                "TokenType": "JWT",
                "Properties": {
                    "AuthMethod": "RPS",
                    "SiteName":   "user.auth.xboxlive.com",
                    "RpsTicket":  rps_token,
                },
            },
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=30,
        )
        if response.status_code == 200:
            token = response.json().get("Token")
            if token:
                return token
        return None
    except Exception:
        return None


def _get_xsts_token(session: requests.Session, user_token: str) -> Tuple[Optional[str], Optional[str]]:
    try:
        response = session.post(
            "https://xsts.auth.xboxlive.com/xsts/authorize",
            json={
                "RelyingParty": "http://xboxlive.com",
                "TokenType": "JWT",
                "Properties": {
                    "UserTokens": [user_token],
                    "SandboxId":  "RETAIL",
                },
            },
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=30,
        )
        if response.status_code == 200:
            data       = response.json()
            uhs        = data.get("DisplayClaims", {}).get("xui", [{}])[0].get("uhs")
            xsts_token = data.get("Token")
            if uhs and xsts_token:
                return uhs, xsts_token
        return None, None
    except Exception:
        return None, None


def get_xbox_tokens(session: requests.Session, rps_token: str) -> Tuple[Optional[str], Optional[str]]:
    for attempt in range(MAX_RETRIES):
        try:
            user_token = _get_user_token(session, rps_token)
            if not user_token:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(BASE_DELAY * 2 ** attempt)
                    continue
                return None, None

            uhs, xsts_token = _get_xsts_token(session, user_token)
            if uhs and xsts_token:
                return uhs, xsts_token

            if attempt < MAX_RETRIES - 1:
                time.sleep(BASE_DELAY * 2 ** attempt)

        except Exception:
            if attempt < MAX_RETRIES - 1:
                time.sleep(BASE_DELAY * 2 ** attempt)

    return None, None


def get_gamertag(session: requests.Session, uhs: str, xsts_token: str) -> Optional[str]:
    try:
        response = session.get(
            "https://profile.xboxlive.com/users/me/profile/settings",
            headers={
                "Authorization":        f"XBL3.0 x={uhs};{xsts_token}",
                "x-xbl-contract-version": "3",
            },
            params={"settings": "Gamertag"},
            timeout=30,
        )
        if response.status_code == 200:
            settings = response.json().get("profileUsers", [{}])[0].get("settings", [])
            for setting in settings:
                if setting.get("id") == "Gamertag":
                    return setting.get("value")
        return None
    except Exception:
        return None


def _get_perks_list(session: requests.Session, uhs: str, xsts_token: str) -> Optional[Dict]:
    try:
        response = session.get(
            "https://profile.gamepass.com/v2/offers",
            headers={
                "Authorization": f"XBL3.0 x={uhs};{xsts_token}",
                "Content-Type":  "application/json",
                "User-Agent":    "okhttp/4.12.0",
            },
            timeout=30,
        )
        return response.json() if response.status_code == 200 else None
    except Exception:
        return None


def _get_offer_details(session: requests.Session, uhs: str, xsts_token: str, offer_id: str) -> Optional[Dict]:
    try:
        response = session.get(
            f"https://profile.gamepass.com/v2/offers/{offer_id}",
            headers={
                "Authorization": f"XBL3.0 x={uhs};{xsts_token}",
                "Content-Type":  "application/json",
                "User-Agent":    "okhttp/4.12.0",
            },
            timeout=30,
        )
        return response.json() if response.status_code == 200 else None
    except Exception:
        return None


def _claim_offer(session: requests.Session, uhs: str, xsts_token: str, offer_id: str) -> Optional[str]:
    try:
        cv_base  = "".join(random.choices(string.ascii_letters + string.digits, k=22))
        ms_cv    = f"{cv_base}.0"
        original_headers = dict(session.headers)
        session.headers.clear()
        try:
            response = session.post(
                f"https://profile.gamepass.com/v2/offers/{offer_id}",
                headers={
                    "Authorization":  f"XBL3.0 x={uhs};{xsts_token}",
                    "content-type":   "application/json",
                    "User-Agent":     "okhttp/4.12.0",
                    "ms-cv":          ms_cv,
                    "Accept-Encoding":"gzip",
                    "Connection":     "Keep-Alive",
                    "Host":           "profile.gamepass.com",
                    "Content-Length": "0",
                },
                data="",
                timeout=30,
            )
            if response.status_code == 200:
                code = response.json().get("resource")
                if code:
                    return code
        finally:
            session.headers.clear()
            session.headers.update(original_headers)
    except Exception:
        pass
    return None


def fetch_codes(session: requests.Session, uhs: str, xsts_token: str) -> List[Dict]:
    results = []
    try:
        perks_data = _get_perks_list(session, uhs, xsts_token)
        if not perks_data:
            return []

        offers = perks_data if isinstance(perks_data, list) else perks_data.get("offers", [])

        for offer in offers:
            offer_id = offer.get("offerId") or offer.get("id")
            if not offer_id:
                continue

            details  = _get_offer_details(session, uhs, xsts_token, offer_id)
            status   = "unknown"
            claimed_date = None

            if details:
                status       = details.get("status", "available")
                claimed_date = details.get("claimedDate")

            code = None
            if status not in ("claimed", "expired"):
                code = _claim_offer(session, uhs, xsts_token, offer_id)

            results.append({
                "code":         code,
                "offer_id":     offer_id,
                "status":       "claimed" if code else status,
                "claimed_date": claimed_date,
            })

    except Exception:
        pass

    return results


def run(session: requests.Session, rps_token: str) -> Dict:
    uhs, xsts_token = get_xbox_tokens(session, rps_token)
    if not uhs or not xsts_token:
        return {"uhs": None, "xsts_token": None, "gamertag": None, "codes": []}

    gamertag = get_gamertag(session, uhs, xsts_token)
    codes    = fetch_codes(session, uhs, xsts_token)

    return {
        "uhs":        uhs,
        "xsts_token": xsts_token,
        "gamertag":   gamertag,
        "codes":      codes,
    }