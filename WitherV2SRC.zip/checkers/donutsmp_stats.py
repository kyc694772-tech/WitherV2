import configparser
import os
import re
import threading
import time

import requests
import urllib3
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

DONUT_API_URL = "https://api.donutsmp.net/v1/stats/"
_file_lock = threading.Lock()

_cfg = configparser.ConfigParser()
_cfg.read("config.ini")

def _get(section, key, fallback=None):
    try:
        return _cfg.get(section, key)
    except Exception:
        return fallback

DONUT_STATS_ENABLED = _get("DonutSMP", "donut_stats", "false").strip().lower() == "true"
DONUT_API_KEY = _get("DonutSMP", "donut_api_key", "").strip()
OUTPUT_FILE = "donutsmp_stats.txt"

BAN_ID_RE = re.compile(r"Ban ID: ([A-Za-z0-9]+)")

def _parse_ban_info(ban_text):
    info = {"ban_id": None, "duration": None}
    if not ban_text or not isinstance(ban_text, str):
        return info
    m = BAN_ID_RE.search(ban_text)
    if m:
        info["ban_id"] = m.group(1)
    if "permanently" in ban_text.lower():
        info["duration"] = "Permanently"
    else:
        m2 = re.search(r"\[([^\]]+)\]", ban_text)
        if m2:
            info["duration"] = m2.group(1)
    return info

def _format_seconds(seconds_value):
    try:
        total_seconds = int(seconds_value)
    except Exception:
        return str(seconds_value)
    if total_seconds < 0:
        total_seconds = 0
    days, rem = divmod(total_seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, _ = divmod(rem, 60)
    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    if not parts:
        parts.append("0m")
    return " ".join(parts)

def _build_session():
    session = requests.Session()
    retry = Retry(
        total=3,
        backoff_factor=0.75,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["GET"],
        respect_retry_after_header=True,
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session

def _build_headers():
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "application/json",
    }
    if DONUT_API_KEY and DONUT_API_KEY != "YOUR_DONUT_API_KEY":
        headers["Authorization"] = f"Bearer {DONUT_API_KEY}"
    return headers

def _find_valid_proxy(session, headers, proxy_list):
    candidates = []
    seen = set()
    for p in proxy_list:
        key = str(p)
        if key not in seen:
            seen.add(key)
            candidates.append(p)
    candidates.append(None)

    valid = []
    for p in candidates:
        try:
            r = session.get(
                "https://api.donutsmp.net/index.html",
                headers=headers, proxies=p, verify=False, timeout=10,
            )
            if r.status_code == 200:
                valid.append(p)
        except Exception:
            pass
    return valid if valid else [None]

def check_donut_smp(email, password, username, ban_status=None, proxy_list=None):
    if not DONUT_STATS_ENABLED:
        return None

    if not username or username == "N/A":
        return None

    if proxy_list is None:
        proxy_list = []

    session = _build_session()
    headers = _build_headers()
    valid_proxies = _find_valid_proxy(session, headers, proxy_list)

    response = None
    for idx, proxy in enumerate(valid_proxies):
        try:
            r = session.get(
                f"{DONUT_API_URL}{username}",
                headers=headers, proxies=proxy, verify=False, timeout=20,
            )
            time.sleep(0.3 * (idx + 1))
            if r.status_code in (200, 401, 404, 429):
                response = r
                break
        except (
            requests.exceptions.ConnectionError,
            requests.exceptions.Timeout,
            requests.exceptions.RetryError,
            requests.exceptions.ProxyError,
            requests.exceptions.SSLError,
            requests.exceptions.InvalidSchema,
        ):
            continue

    if response is None:
        return None

    if response.status_code == 401:
        return {"error": "Invalid API key"}
    if response.status_code == 404:
        return {"error": "Player not found"}
    if response.status_code == 429:
        return {"error": "Rate limited"}
    if response.status_code != 200:
        return None

    try:
        data = response.json()
    except Exception:
        return None

    stats_data = None
    if isinstance(data, dict) and "result" in data and isinstance(data["result"], dict):
        stats_data = data["result"]

    if not isinstance(stats_data, dict):
        return None

    lines = []
    lines.append(f"{email}:{password}")
    lines.append(f"Username: {username}")

    for field in [
        "broken_blocks", "deaths", "kills", "mobs_killed",
        "money", "money_made_from_sell", "money_spent_on_shop", "placed_blocks",
    ]:
        if stats_data.get(field):
            lines.append(f"{field}: {stats_data[field]}")

    if stats_data.get("playtime"):
        raw = stats_data["playtime"]
        lines.append(f"playtime: {raw} ({_format_seconds(raw)})")

    if ban_status is not None:
        if ban_status and ban_status != "False":
            lines.append("banned: true")
            if ban_status not in ("True", "true", True):
                info = _parse_ban_info(ban_status)
                if info.get("ban_id"):
                    lines.append(f"ban_id: {info['ban_id']}")
                if info.get("duration"):
                    lines.append(f"ban_duration: {info['duration']}")
            else:
                lines.append("ban_duration: Unknown")
        else:
            lines.append("banned: false")

    if len(lines) <= 2:
        return None

    result = dict(zip(
        ["broken_blocks", "deaths", "kills", "mobs_killed",
         "money", "money_made_from_sell", "money_spent_on_shop",
         "placed_blocks", "playtime"],
        [stats_data.get(f) for f in [
            "broken_blocks", "deaths", "kills", "mobs_killed",
            "money", "money_made_from_sell", "money_spent_on_shop",
            "placed_blocks", "playtime",
        ]],
    ))

    with _file_lock:
        with open(OUTPUT_FILE, "a", encoding="utf-8") as f:
            f.write("\n".join(lines))
            f.write("\n" + "=" * 50 + "\n")

    return result