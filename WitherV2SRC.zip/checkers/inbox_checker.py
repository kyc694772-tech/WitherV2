import configparser
import time
from urllib.parse import urlparse, parse_qs

import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

_cfg = configparser.ConfigParser()
_cfg.read("config.ini")

def _get(section, key, fallback=None):
    try:
        return _cfg.get(section, key).strip()
    except Exception:
        return fallback

SCAN_INBOX      = _get("Inbox", "scan_inbox", "false").lower() == "true"
INBOX_KEYWORDS  = [k.strip() for k in _get("Inbox", "inbox_keywords", "").split(",") if k.strip()]
TIMEOUT         = int(_get("General", "timeout", "10"))

_TOKEN_CACHE         = {}
_TOKEN_CACHE_TIMEOUT = 300

_SEARCH_URL = "https://outlook.live.com/search/api/v2/query?n=124&cv=tNZ1DVP5NhDwG%2FDUCelaIu.124"
_SEARCH_PAYLOAD_TEMPLATE = {
    "Cvid": "7ef2720e-6e59-ee2b-a217-3a4f427ab0f7",
    "Scenario": {"Name": "owa.react"},
    "TimeZone": "Egypt Standard Time",
    "TextDecorations": "Off",
    "EntityRequests": [
        {
            "EntityType": "Conversation",
            "ContentSources": ["Exchange"],
            "Filter": {
                "Or": [
                    {"Term": {"DistinguishedFolderName": "msgfolderroot"}},
                    {"Term": {"DistinguishedFolderName": "DeletedItems"}},
                ]
            },
            "From": 0,
            "Query": {"QueryString": ""},
            "RefiningQueries": None,
            "Size": 25,
            "Sort": [
                {"Field": "Score", "SortDirection": "Desc", "Count": 3},
                {"Field": "Time",  "SortDirection": "Desc"},
            ],
            "EnableTopResults": True,
            "TopResultsCount": 3,
        }
    ],
    "AnswerEntityRequests": [
        {
            "Query": {"QueryString": ""},
            "EntityTypes": ["Event", "File"],
            "From": 0,
            "Size": 10,
            "EnableAsyncResolution": True,
        }
    ],
    "QueryAlterationOptions": {
        "EnableSuggestion": True,
        "EnableAlteration": True,
        "SupportedRecourseDisplayTypes": [
            "Suggestion",
            "NoResultModification",
            "NoResultFolderRefinerModification",
            "NoRequeryModification",
            "Modification",
        ],
    },
    "LogicalId": "446c567a-02d9-b739-b9ca-616e0d45905c",
}

def _get_auth_token(session, client_id, scope, redirect_uri):
    cache_key = f"{client_id}:{scope}:{redirect_uri}"
    if cache_key in _TOKEN_CACHE:
        entry = _TOKEN_CACHE[cache_key]
        if time.time() - entry["timestamp"] < _TOKEN_CACHE_TIMEOUT:
            return entry["token"]
    try:
        auth_url = (
            f"https://login.live.com/oauth20_authorize.srf"
            f"?client_id={client_id}&response_type=token"
            f"&scope={scope}&redirect_uri={redirect_uri}&prompt=none"
        )
        r = session.get(auth_url, timeout=TIMEOUT)
        token = parse_qs(urlparse(r.url).fragment).get("access_token", [None])[0]
        if token:
            _TOKEN_CACHE[cache_key] = {"token": token, "timestamp": time.time()}
        return token
    except (requests.RequestException, TimeoutError, ConnectionError):
        return None

def _get_inbox_token(session, email):
    token = _get_auth_token(
        session,
        "0000000048170EF2",
        "https://substrate.office.com/User-Internal.ReadWrite",
        "https://login.live.com/oauth20_desktop.srf",
    )
    if not token:
        token = _get_auth_token(
            session,
            "0000000048170EF2",
            "service::outlook.office.com::MBI_SSL",
            "https://login.live.com/oauth20_desktop.srf",
        )
    return token

def _get_cid(session, email):
    cid = session.cookies.get("MSPCID")
    if not cid:
        try:
            session.get("https://outlook.live.com/owa/", timeout=TIMEOUT)
            cid = session.cookies.get("MSPCID")
        except Exception:
            pass
    return cid or email

def _build_payload(keyword):
    import copy
    payload = copy.deepcopy(_SEARCH_PAYLOAD_TEMPLATE)
    payload["EntityRequests"][0]["Query"]["QueryString"]         = keyword
    payload["AnswerEntityRequests"][0]["Query"]["QueryString"]   = keyword
    return payload

def check_inbox(session, email, keywords=None):
    if not SCAN_INBOX:
        return []

    if keywords is None:
        keywords = INBOX_KEYWORDS

    if not keywords:
        return []

    try:
        token = _get_inbox_token(session, email)
        if not token:
            return []

        cid = _get_cid(session, email)
        headers = {
            "Authorization":  f"Bearer {token}",
            "X-AnchorMailbox": f"CID:{cid}",
            "Content-Type":   "application/json",
            "User-Agent":     "Outlook-Android/2.0",
            "Accept":         "application/json",
            "Host":           "substrate.office.com",
        }

        results = []
        for keyword in keywords:
            try:
                r = session.post(
                    _SEARCH_URL,
                    json=_build_payload(keyword),
                    headers=headers,
                    timeout=15,
                )
                if r.status_code != 200:
                    continue
                data  = r.json()
                total = 0
                if "EntitySets" in data:
                    for entity_set in data["EntitySets"]:
                        if "ResultSets" in entity_set:
                            for result_set in entity_set["ResultSets"]:
                                if "Total" in result_set:
                                    total += result_set["Total"]
                                elif "ResultCount" in result_set:
                                    total += result_set["ResultCount"]
                                elif "Results" in result_set:
                                    total += len(result_set["Results"])
                if total > 0:
                    results.append((keyword, total))
            except Exception:
                pass

        return results

    except Exception:
        return []